
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

interface ComicCard {
  id: number;
  title: string;
  chapters: string;
  rating: string;
  thumbnail: string;
}

export default function ComicPage() {
  const [showModal, setShowModal] = useState(false);
  const [selectedComic, setSelectedComic] = useState<ComicCard | null>(null);
  const [displayedComics, setDisplayedComics] = useState(20);
  const [selectedCategory, setSelectedCategory] = useState('漫画');
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [config, setConfig] = useState<any>(null);

  const navigate = useNavigate();

  const categories = ['动漫', '漫画', '游戏', '真人', '写真'];

  // 从localStorage加载配置
  useEffect(() => {
    const loadConfig = () => {
      const savedConfig = localStorage.getItem('adminConfig');
      if (savedConfig) {
        try {
          const parsedConfig = JSON.parse(savedConfig);
          setConfig(parsedConfig);
        } catch (error) {
          console.error('配置解析错误:', error);
        }
      }
    };

    loadConfig();

    // 监听localStorage变化
    const handleStorageChange = () => {
      loadConfig();
    };

    window.addEventListener('storage', handleStorageChange);
    const configCheckInterval = setInterval(loadConfig, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(configCheckInterval);
    };
  }, []);

  // 默认漫画数据（作为后备）
  const defaultComicData: ComicCard[] = [
    { id: 1, title: '纲手的午休时间', chapters: '72话', rating: '9.8', thumbnail: 'https://tcp.baby/static/images/61.jpg' },
    { id: 2, title: '雷影忍者', chapters: '10话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/62.jpg' },
    { id: 3, title: '大理寺巡街使', chapters: '20话', rating: '9.5', thumbnail: 'https://tcp.baby/static/images/63.jpg' },
    { id: 4, title: '哪吒-玉虚宫战役', chapters: '19话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/64.jpg' },
    { id: 5, title: '哪吒-捆仙绳', chapters: '46话', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/65.jpg' },
    { id: 6, title: '鸣人的妻子', chapters: '48话', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/66.jpg' },
    { id: 7, title: 'S诱鸣人之术', chapters: '93话', rating: '9.6', thumbnail: 'https://tcp.baby/static/images/67.jpg' },
    { id: 8, title: '杨玉环-上元灯会奇遇', chapters: '39话', rating: '9.8', thumbnail: 'https://tcp.baby/static/images/68.jpg' },
    { id: 9, title: '小樱捆绑XX', chapters: '29话', rating: '9.3', thumbnail: 'https://tcp.baby/static/images/69.jpg' },
    { id: 10, title: '甄姬与幼童', chapters: '47话', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/70.jpg' },
    { id: 11, title: '北北北砂-合集', chapters: '99话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/71.jpg' },
    { id: 12, title: '小乔NTR', chapters: '22话', rating: '9.6', thumbnail: 'https://tcp.baby/static/images/72.jpg' },
    { id: 13, title: '小文姬的大人游戏', chapters: '13话', rating: '9.9', thumbnail: 'https://tcp.baby/static/images/73.jpg' },
    { id: 14, title: '瑶的全收集之路', chapters: '68话', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/74.jpg' },
    { id: 15, title: '大小姐的街边服务', chapters: '45话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/75.jpg' },
    { id: 16, title: '王者-大话西游同人', chapters: '37话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/76.jpg' },
    { id: 17, title: '长安之乱', chapters: '24话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/77.jpg' },
    { id: 18, title: '镜的欢迎会', chapters: '34话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/78.jpg' },
    { id: 19, title: '虞姬寝取', chapters: '54话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/79.jpg' },
    { id: 20, title: '圣诞礼物', chapters: '73话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/80.jpg' }
  ];

  // 使用配置中的漫画数据或默认数据
  const comicData = config?.comic?.comics?.map((comic: any, index: number) => ({
    id: index + 1,
    ...comic
  })) || defaultComicData;

  const handleComicClick = (comic: ComicCard) => {
    setSelectedComic(comic);
    setShowModal(true);
  };

  const handleLoadMore = () => {
    setIsLoading(true);
    setLoadingProgress(0);
    
    const interval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsLoading(false);
          setDisplayedComics(prev => Math.min(prev + 8, comicData.length));
          return 100;
        }
        return prev + 2;
      });
    }, 50);
  };

  const ComicCard = ({ comic }: { comic: ComicCard }) => (
    <div 
      className="relative bg-black rounded-xl overflow-hidden cursor-pointer hover:scale-105 transition-all duration-300 hover:shadow-2xl group border border-gray-800"
      onClick={() => handleComicClick(comic)}
    >
      <div className="relative">
        <img 
          src={comic.thumbnail} 
          alt={comic.title} 
          className="w-full h-48 object-cover object-top" 
        />
        <div className="absolute top-2 right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded font-bold shadow-lg">
          VIP
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div className="absolute bottom-2 left-2 right-2 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="text-xs font-medium truncate mb-1">{comic.title}</div>
          <div className="flex justify-between text-xs">
            <span>{comic.chapters}</span>
            <span className="flex items-center">
              <i className="ri-star-fill text-yellow-400 mr-1"></i>
              {comic.rating}
            </span>
          </div>
        </div>
      </div>
      <div className="p-3 bg-gray-900 border-t border-gray-800">
        <h3 className="text-white text-sm font-medium mb-2 truncate">{comic.title}</h3>
        <div className="flex justify-between text-xs text-gray-400">
          <span className="flex items-center">
            <i className="ri-book-2-line mr-1"></i>
            {comic.chapters}
          </span>
          <span className="flex items-center">
            <i className="ri-star-fill text-yellow-400 mr-1"></i>
            {comic.rating}
          </span>
        </div>
      </div>
    </div>
  );

  const handleCategoryClick = (category: string) => {
    if (category === '动漫') {
      navigate('/home');
    } else if (category === '游戏') {
      navigate('/game');
    } else {
      setSelectedCategory(category);
    }
  };

  const handleNavigateToTutorial = () => {
    setShowModal(false);
    navigate('/landing');
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="bg-black border-b border-gray-800 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="text-orange-500 text-xl font-bold">
              {config?.comic?.title || '全部免费'}
            </div>
            <div className="flex space-x-4">
              <button className="text-gray-400 hover:text-white transition-colors">
                <i className="ri-search-line text-lg"></i>
              </button>
              <button className="text-gray-400 hover:text-white transition-colors">
                <i className="ri-menu-line text-lg"></i>
              </button>
            </div>
          </div>
          <nav className="flex justify-center space-x-8 border-b border-gray-800">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => handleCategoryClick(category)}
                className={`text-sm px-0 py-3 transition-all relative ${
                  selectedCategory === category
                    ? 'text-orange-500 font-medium'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {category}
                {selectedCategory === category && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500"></div>
                )}
              </button>
            ))}
          </nav>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <h2 className="text-orange-500 text-2xl font-bold text-center mb-8 border-b border-orange-500 pb-2 inline-block w-full">漫画库</h2>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 pb-8">
        {/* Comic Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 mb-8">
          {comicData.slice(0, displayedComics).map((comic) => (
            <ComicCard key={comic.id} comic={comic} />
          ))}
        </div>

        {/* Load More Button */}
        {displayedComics < comicData.length && (
          <div className="text-center mb-8">
            <button 
              onClick={handleLoadMore}
              disabled={isLoading}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 disabled:opacity-50 text-white px-12 py-4 rounded-full text-base font-medium transition-all transform hover:scale-105 disabled:hover:scale-100 shadow-lg"
            >
              {isLoading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  加载中...
                </div>
              ) : (
                '点击显示更多'
              )}
            </button>
            
            {/* Loading Progress Bar */}
            {isLoading && (
              <div className="mt-4 max-w-xs mx-auto">
                <div className="bg-gray-800 rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-orange-500 to-red-500 h-full transition-all duration-100 ease-out"
                    style={{ width: `${loadingProgress}%` }}
                  ></div>
                </div>
                <div className="text-gray-400 text-xs mt-2">{loadingProgress}%</div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 text-center py-6">
        <p className="text-gray-400 text-sm">
          {config?.comic?.footer || '© 2025 漫画星球 · 专属于各位漫画迷的资源'}
        </p>
      </footer>

      {/* Modal */}
      {showModal && selectedComic && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-lg p-6 max-w-sm w-full text-center border border-gray-700">
            <h2 className="text-white text-lg font-bold mb-2">解锁更多漫画内容</h2>
            <p className="text-gray-400 text-sm mb-4">登录白嫖动漫/漫画/游戏/真人</p>
            
            <div className="bg-gray-800 rounded-lg p-4 mb-4 border border-gray-700">
              <h3 className="text-white font-medium mb-1">免费获取</h3>
              <p className="text-orange-500 text-sm mb-1">简单几步 直接打开</p>
              <p className="text-gray-400 text-xs mb-3">还有100G网盘资源限时分享</p>
              
              {/* 合并为一个明显的可点击按钮 */}
              <button 
                onClick={handleNavigateToTutorial}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg text-sm font-medium transition-colors border border-blue-500 hover:border-blue-400 shadow-md hover:shadow-lg"
              >
                <div className="flex items-center justify-center space-x-2">
                  <i className="ri-arrow-right-circle-fill text-lg"></i>
                  <span>点击查看详细教程</span>
                </div>
              </button>
            </div>

            <div className="flex space-x-3">
              <button 
                onClick={() => setShowModal(false)}
                className="flex-1 text-gray-400 text-sm hover:text-white transition-colors"
              >
                稍后决定
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
