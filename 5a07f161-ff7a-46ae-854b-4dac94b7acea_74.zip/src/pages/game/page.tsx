
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

interface GameCard {
  id: number;
  title: string;
  tag: string;
  mode: string;
  rating: string;
  thumbnail: string;
}

export default function GamePage() {
  const [showModal, setShowModal] = useState(false);
  const [selectedGame, setSelectedGame] = useState<GameCard | null>(null);
  const [displayedGames, setDisplayedGames] = useState(18);
  const [selectedCategory, setSelectedCategory] = useState('游戏');
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [config, setConfig] = useState<any>(null);

  const navigate = useNavigate();

  const categories = ['动漫', '漫画', '游戏', '真人', '写真'];

  // 从localStorage加载配置
  useEffect(() => {
    const loadConfig = () => {
      const savedConfig = localStorage.getItem('adminConfig');
      if (savedConfig) {
        try {
          const parsedConfig = JSON.parse(savedConfig);
          setConfig(parsedConfig);
        } catch (error) {
          console.error('配置解析错误:', error);
        }
      }
    };

    loadConfig();

    // 监听localStorage变化
    const handleStorageChange = () => {
      loadConfig();
    };

    window.addEventListener('storage', handleStorageChange);
    const configCheckInterval = setInterval(loadConfig, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(configCheckInterval);
    };
  }, []);

  // 默认游戏数据（作为后备）
  const defaultGameData: GameCard[] = [
    { id: 1, title: '时间停止', tag: '角色扮演', mode: '多人', rating: '9.3', thumbnail: 'https://tcp.baby/static/images/81.jpg' },
    { id: 2, title: '与纲手同居', tag: '动作', mode: '单人', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/82.jpg' },
    { id: 3, title: '极品采花郎', tag: '动作', mode: '多人', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/83.jpg' },
    { id: 4, title: '夜幕之花', tag: '动作', mode: '单人', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/84.jpg' },
    { id: 5, title: '忍者后宫', tag: '动作', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/85.jpg' },
    { id: 6, title: '隔壁的女主播', tag: '动作', mode: '单人', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/86.jpg' },
    { id: 7, title: '教育女忍:最后的战争', tag: '动作', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/87.jpg' },
    { id: 8, title: '火影:被诅咒的忍术', tag: '动作', mode: '单人', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/88.jpg' },
    { id: 9, title: '海贼传:路飞的艳遇', tag: '策略', mode: '多人', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/89.jpg' },
    { id: 10, title: '暗影刺客:复仇之路', tag: '动作', mode: '单人', rating: '9.1', thumbnail: 'https://tcp.baby/static/images/90.jpg' },
    { id: 11, title: '龙之纪元:命运召唤', tag: '角色扮演', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/91.jpg' },
    { id: 12, title: '未来都市:赛博朋克', tag: '冒险', mode: '单人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/92.jpg' },
    { id: 13, title: '荒野求生:极限生存', tag: '冒险', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/93.jpg' },
    { id: 14, title: '火影:女忍训练师', tag: '角色扮演', mode: '单人', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/94.jpg' },
    { id: 15, title: '火影:学长的生活', tag: '竞速', mode: '多人', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/95.jpg' },
    { id: 16, title: '火影:忍者领主', tag: '策略', mode: '单人', rating: '9.1', thumbnail: 'https://tcp.baby/static/images/96.jpg' },
    { id: 17, title: '火影:火影崛起', tag: '策略', mode: '多人', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/97.jpg' },
    { id: 18, title: '火影:火影人生', tag: '策略', mode: '单人', rating: '9.1', thumbnail: 'https://tcp.baby/static/images/98.jpg' },
    { id: 19, title: '王者荣耀:峡谷传说', tag: '竞技', mode: '多人', rating: '9.5', thumbnail: 'https://tcp.baby/static/images/99.jpg' },
    { id: 20, title: '原神:提瓦特大陆', tag: '冒险', mode: '单人', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/100.jpg' }
  ];

  // 使用配置中的游戏数据或默认数据
  const gameData = config?.game?.games?.map((game: any, index: number) => ({
    id: index + 1,
    ...game
  })) || defaultGameData;

  const handleGameClick = (game: GameCard) => {
    setSelectedGame(game);
    setShowModal(true);
  };

  const handleLoadMore = () => {
    setIsLoading(true);
    setLoadingProgress(0);
    
    const interval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsLoading(false);
          setDisplayedGames(prev => Math.min(prev + 6, gameData.length));
          return 100;
        }
        return prev + 3;
      });
    }, 80);
  };

  const GameCard = ({ game }: { game: GameCard }) => (
    <div 
      className="relative bg-black rounded-lg overflow-hidden cursor-pointer hover:scale-105 transition-all duration-300 hover:shadow-2xl group border border-gray-800"
      onClick={() => handleGameClick(game)}
    >
      <div className="relative">
        <img 
          src={game.thumbnail} 
          alt={game.title} 
          className="w-full h-48 object-cover object-top" 
        />
        <div className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded font-bold shadow-lg">
          VIP
        </div>
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
          <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform group-hover:scale-110">
            <i className="ri-play-fill text-black text-2xl ml-1"></i>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div className="absolute bottom-2 left-2 right-2 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="text-sm font-bold truncate mb-1">{game.title}</div>
          <div className="flex justify-between text-xs">
            <span className="bg-green-500 px-2 py-1 rounded text-white font-medium">{game.tag}</span>
            <span className="bg-black/50 px-2 py-1 rounded">{game.rating}</span>
          </div>
        </div>
      </div>
      <div className="p-3 bg-gray-900 border-t border-gray-700">
        <h3 className="text-white text-sm font-bold mb-1 truncate">{game.title}</h3>
        <div className="mb-2">
          <span className="text-green-400 text-xs bg-green-500/20 px-2 py-1 rounded font-medium">{game.tag}</span>
        </div>
        <div className="flex justify-between text-xs text-gray-400">
          <span>{game.mode}</span>
          <span className="text-yellow-400 font-medium">{game.rating}</span>
        </div>
      </div>
    </div>
  );

  const handleCategoryClick = (category: string) => {
    if (category === '动漫') {
      navigate('/home');
    } else if (category === '漫画') {
      navigate('/comic');
    } else {
      setSelectedCategory(category);
    }
  };

  const handleNavigateToTutorial = () => {
    setShowModal(false);
    navigate('/landing');
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="bg-black border-b border-gray-800 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                <i className="ri-check-line text-white text-sm"></i>
              </div>
              <div className="text-white text-lg font-bold">
                {config?.game?.title || '公益站 纯免费'}
              </div>
            </div>
            <div className="flex space-x-4">
              <button className="text-gray-400 hover:text-white transition-colors">
                <i className="ri-search-line text-lg"></i>
              </button>
              <button className="text-gray-400 hover:text-white transition-colors">
                <i className="ri-menu-line text-lg"></i>
              </button>
            </div>
          </div>
          <nav className="flex justify-center space-x-8">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => handleCategoryClick(category)}
                className={`text-sm px-0 py-3 transition-all relative ${
                  selectedCategory === category
                    ? 'text-green-500 font-bold'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {category}
                {selectedCategory === category && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-500"></div>
                )}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Section Title */}
      <div className="container mx-auto px-4 py-6">
        <h2 className="text-green-500 text-2xl font-bold text-center mb-8 border-b border-green-500 pb-2 inline-block w-full">游戏库</h2>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 pb-8">
        {/* Game Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
          {gameData.slice(0, displayedGames).map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>

        {/* Load More Button */}
        {displayedGames < gameData.length && (
          <div className="text-center mb-8">
            <button 
              onClick={handleLoadMore}
              disabled={isLoading}
              className="bg-green-500 hover:bg-green-600 disabled:opacity-50 text-white px-12 py-4 rounded-full text-base font-bold transition-all transform hover:scale-105 disabled:hover:scale-100 shadow-lg border-2 border-green-400"
            >
              {isLoading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  加载中...
                </div>
              ) : (
                '点击显示更多'
              )}
            </button>
            
            {/* Loading Progress Bar */}
            {isLoading && (
              <div className="mt-4 max-w-xs mx-auto">
                <div className="bg-gray-800 rounded-full h-3 overflow-hidden border border-gray-700">
                  <div 
                    className="bg-gradient-to-r from-green-400 to-green-600 h-full transition-all duration-100 ease-out"
                    style={{ width: `${loadingProgress}%` }}
                  ></div>
                </div>
                <div className="text-green-400 text-sm mt-2 font-medium">{loadingProgress}%</div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 text-center py-6">
        <p className="text-gray-400 text-sm">
          {config?.game?.footer || '© 2025 游戏世界 · 专属于各位玩家的VIP游戏库'}
        </p>
      </footer>

      {/* Modal */}
      {showModal && selectedGame && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-lg p-6 max-w-sm w-full text-center border border-gray-700">
            <h2 className="text-white text-lg font-bold mb-2">解锁更多游戏内容</h2>
            <p className="text-gray-400 text-sm mb-4">登录白嫖动漫/漫画/游戏/真人</p>
            
            <div className="bg-gray-800 rounded-lg p-4 mb-4 border border-gray-700">
              <h3 className="text-white font-medium mb-1">免费获取</h3>
              <p className="text-green-500 text-sm mb-1">简单几步 直接打开</p>
              <p className="text-gray-400 text-xs mb-3">还有100G网盘资源限时分享</p>
              
              {/* 合并为一个明显的可点击按钮 */}
              <button 
                onClick={handleNavigateToTutorial}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg text-sm font-medium transition-colors border border-blue-500 hover:border-blue-400 shadow-md hover:shadow-lg"
              >
                <div className="flex items-center justify-center space-x-2">
                  <i className="ri-arrow-right-circle-fill text-lg"></i>
                  <span>点击查看详细教程</span>
                </div>
              </button>
            </div>

            <div className="flex space-x-3">
              <button 
                onClick={() => setShowModal(false)}
                className="flex-1 text-gray-400 text-sm hover:text-white transition-colors"
              >
                稍后决定
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
