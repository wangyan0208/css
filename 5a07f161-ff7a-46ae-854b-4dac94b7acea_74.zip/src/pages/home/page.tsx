
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface VideoCard {
  id: number;
  title: string;
  duration: string;
  rating: string;
  thumbnail: string;
}

interface VideoSection {
  title: string;
  videos: VideoCard[];
}

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState('动漫');
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState<'video' | 'loadMore'>('video');
  const [currentSection, setCurrentSection] = useState('');
  const [visibleSections, setVisibleSections] = useState<{ [key: string]: number }>({
    '番漫同人': 8,
    '火影忍者同人': 8,
    '哪吒同人系列': 8,
    '王者系列同人': 8,
    '国漫/原神系列同人': 8
  });

  const navigate = useNavigate();
  const categories = ['动漫', '漫画', '游戏', '真人', '写真'];

  const videoSections: VideoSection[] = [
    {
      title: '番漫同人',
      videos: [
        { id: 1, title: '枫与铃1~3', duration: '58分钟', rating: '9.8', thumbnail: 'https://tcp.baby/static/images/1.jpg' },
        { id: 2, title: '我的妈妈', duration: '21分钟', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/2.jpg' },
        { id: 3, title: '约尔过家家', duration: '19分钟', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/3.jpg' },
        { id: 4, title: '催眠指导', duration: '22分钟', rating: '9.9', thumbnail: 'https://tcp.baby/static/images/4.jpg' },
        { id: 5, title: '2B小姐姐', duration: '15分钟', rating: '9.5', thumbnail: 'https://tcp.baby/static/images/5.jpg' },
        { id: 6, title: '撤退的矮子', duration: '25分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/6.jpg' },
        { id: 7, title: '紫阳花', duration: '21分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/7.jpg' },
        { id: 8, title: '召唤魅魔', duration: '22分钟', rating: '8.3', thumbnail: 'https://tcp.baby/static/images/8.jpg' },
        { id: 9, title: '魔法少女', duration: '18分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/9.jpg' },
        { id: 10, title: '学园默示录', duration: '24分钟', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/10.jpg' },
        { id: 11, title: '进击的巨人', duration: '26分钟', rating: '9.1', thumbnail: 'https://tcp.baby/static/images/11.jpg' },
        { id: 12, title: '东京食尸鬼', duration: '23分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/12.jpg' }
      ]
    },
    {
      title: '火影忍者同人',
      videos: [
        { id: 13, title: '纲手火车摇', duration: '14分钟', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/13.jpg' },
        { id: 14, title: '纲手老湿', duration: '9分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/14.jpg' },
        { id: 15, title: '玖幸奈XX', duration: '11分钟', rating: '8.3', thumbnail: 'https://tcp.baby/static/images/15.jpg' },
        { id: 16, title: '鸣人的幸福时光', duration: '12分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/16.jpg' },
        { id: 17, title: '兔子雏田', duration: '13分钟', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/17.jpg' },
        { id: 18, title: '小鸣人的幸福时光', duration: '11分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/18.jpg' },
        { id: 19, title: '足', duration: '21分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/19.jpg' },
        { id: 20, title: '佐良娜的那件事', duration: '22分钟', rating: '8.1', thumbnail: 'https://tcp.baby/static/images/20.jpg' },
        { id: 21, title: '小樱的秘密', duration: '16分钟', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/21.jpg' },
        { id: 22, title: '手鞠的风遁', duration: '19分钟', rating: '8.4', thumbnail: 'https://tcp.baby/static/images/22.jpg' },
        { id: 23, title: '红豆老师', duration: '25分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/23.jpg' },
        { id: 24, title: '静音的医疗忍术', duration: '17分钟', rating: '8.3', thumbnail: 'https://tcp.baby/static/images/24.jpg' }
      ]
    },
    {
      title: '哪吒同人系列',
      videos: [
        { id: 25, title: '鹤童XX鹿童', duration: '14分钟', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/25.jpg' },
        { id: 26, title: '润足', duration: '17分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/26.jpg' },
        { id: 27, title: '殷夫人的母爱', duration: '35分钟', rating: '8.3', thumbnail: 'https://tcp.baby/static/images/27.jpg' },
        { id: 28, title: '鹤童泳装天使', duration: '32分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/28.jpg' },
        { id: 29, title: '用力!用力!', duration: '29分钟', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/29.jpg' },
        { id: 30, title: '鹤童与地铁狼', duration: '11分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/30.jpg' },
        { id: 31, title: '敖闰龙形态', duration: '18分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/31.jpg' },
        { id: 32, title: '锁龙井', duration: '22分钟', rating: '8.1', thumbnail: 'https://tcp.baby/static/images/32.jpg' },
        { id: 33, title: '哪吒的重生', duration: '28分钟', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/33.jpg' },
        { id: 34, title: '太乙真人', duration: '31分钟', rating: '8.4', thumbnail: 'https://tcp.baby/static/images/34.jpg' },
        { id: 35, title: '申公豹的计谋', duration: '26分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/35.jpg' },
        { id: 36, title: '龙宫秘史', duration: '33分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/36.jpg' }
      ]
    },
    {
      title: '王者系列同人',
      videos: [
        { id: 37, title: '冲刺中', duration: '33分钟', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/37.jpg' },
        { id: 38, title: '痛苦摄影', duration: '38分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/38.jpg' },
        { id: 39, title: '老头的云樱', duration: '11分钟', rating: '8.3', thumbnail: 'https://tcp.baby/static/images/39.jpg' },
        { id: 40, title: '云樱与流浪汉', duration: '12分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/40.jpg' },
        { id: 41, title: '西装禽兽', duration: '13分钟', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/41.jpg' },
        { id: 42, title: '吸纳交汇', duration: '18分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/42.jpg' },
        { id: 43, title: '黑大汉与西施', duration: '19分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/43.jpg' },
        { id: 44, title: '镜的惩罚', duration: '13分钟', rating: '8.1', thumbnail: 'https://tcp.baby/static/images/44.jpg' },
        { id: 45, title: '貂蝉の密室', duration: '27分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/45.jpg' },
        { id: 46, title: '大乔小乔', duration: '24分钟', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/46.jpg' },
        { id: 47, title: '甄姬の魅惑', duration: '21分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/47.jpg' },
        { id: 48, title: '武则天后宫', duration: '35分钟', rating: '9.0', thumbnail: 'https://tcp.baby/static/images/48.jpg' }
      ]
    },
    {
      title: '国漫/原神系列同人',
      videos: [
        { id: 49, title: '去衣系列', duration: '14分钟', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/49.jpg' },
        { id: 50, title: '裴仙子XX', duration: '8分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/50.jpg' },
        { id: 51, title: '熟睡的梅花十三', duration: '11分钟', rating: '8.3', thumbnail: 'https://tcp.baby/static/images/51.jpg' },
        { id: 52, title: '战败的刻晴被触手', duration: '16分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/52.jpg' },
        { id: 53, title: '海边刻晴', duration: '25分钟', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/53.jpg' },
        { id: 54, title: '神子的惩罚', duration: '36分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/54.jpg' },
        { id: 55, title: 'VAM柳神', duration: '27分钟', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/55.jpg' },
        { id: 56, title: '小舞的动态合集', duration: '15分钟', rating: '8.1', thumbnail: 'https://tcp.baby/static/images/56.jpg' },
        { id: 57, title: '胡桃的秘密', duration: '19分钟', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/57.jpg' },
        { id: 58, title: '甘雨的工作', duration: '22分钟', rating: '8.4', thumbnail: 'https://tcp.baby/static/images/58.jpg' },
        { id: 59, title: '魈的守护', duration: '28分钟', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/59.jpg' },
        { id: 60, title: '钟离的契约', duration: '31分钟', rating: '8.9', thumbnail: 'https://tcp.baby/static/images/60.jpg' }
      ]
    }
  ];

  const handleVideoClick = () => {
    setModalType('video');
    setShowModal(true);
  };

  const handleLoadMore = (sectionTitle: string) => {
    setCurrentSection(sectionTitle);
    setModalType('loadMore');
    setShowModal(true);
  };

  const handleCategoryClick = (category: string) => {
    if (category === '漫画') {
      navigate('/comic');
    } else if (category === '游戏') {
      navigate('/game');
    } else {
      setSelectedCategory(category);
    }
  };

  const handleNavigateToTutorial = () => {
    setShowModal(false);
    navigate('/landing');
  };

  const VideoCard = ({ video }: { video: VideoCard }) => (
    <div className="relative bg-gray-900 rounded-lg overflow-hidden cursor-pointer hover:scale-105 transition-transform group" onClick={handleVideoClick}>
      <div className="relative">
        <img src={video.thumbnail} alt={video.title} className="w-full h-40 object-cover" />
        <div className="absolute top-2 right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded font-bold">VIP</div>
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
          <div className="w-12 h-12 bg-black/70 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <i className="ri-play-fill text-white text-xl ml-1"></i>
          </div>
        </div>
      </div>
      <div className="p-3 bg-gray-900">
        <h3 className="text-white text-sm font-medium mb-2 truncate">{video.title}</h3>
        <div className="flex justify-between text-xs text-gray-400">
          <span>{video.duration}</span>
          <span>{video.rating}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="bg-black border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="text-center mb-4">
            <h1 className="text-white text-lg font-bold">公益网站 全部免费</h1>
          </div>
          <nav className="flex justify-center space-x-8 border-b border-gray-800">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => handleCategoryClick(category)}
                className={`text-sm px-0 py-2 transition-colors ${
                  selectedCategory === category
                    ? 'text-orange-500 border-b-2 border-orange-500 font-medium'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {category}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-6">
        {videoSections.map((section) => (
          <div key={section.title} className="mb-10">
            <h2 className="text-orange-500 text-xl font-medium mb-6 text-center border-b border-gray-800 pb-2">
              {section.title}
            </h2>
            
            {/* Video Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {section.videos.slice(0, visibleSections[section.title]).map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>

            {/* Load More Button */}
            {visibleSections[section.title] < section.videos.length && (
              <div className="text-center mb-8">
                <button 
                  onClick={() => handleLoadMore(section.title)}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-full text-sm font-medium transition-all transform hover:scale-105"
                >
                  点击显示更多
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 text-center py-6">
        <p className="text-gray-400 text-sm">© 2025 漫画星球 · 专属于各位漫画迷的资源</p>
      </footer>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-lg p-6 max-w-sm w-full text-center border border-gray-700">
            <h2 className="text-white text-lg font-bold mb-2">解锁更多动漫内容</h2>
            <p className="text-gray-400 text-sm mb-4">登录白嫖动漫/漫画/游戏/真人</p>
            
            <div className="bg-gray-800 rounded-lg p-4 mb-4 border border-gray-700">
              <h3 className="text-white font-medium mb-1">免费获取</h3>
              <p className="text-orange-500 text-sm mb-1">简单几步 直接打开</p>
              <p className="text-gray-400 text-xs mb-3">还有100G网盘资源限时分享</p>
              
              {/* 合并为一个明显的可点击按钮 */}
              <button 
                onClick={handleNavigateToTutorial}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg text-sm font-medium transition-colors border border-blue-500 hover:border-blue-400 shadow-md hover:shadow-lg"
              >
                <div className="flex items-center justify-center space-x-2">
                  <i className="ri-arrow-right-circle-fill text-lg"></i>
                  <span>点击查看详细教程</span>
                </div>
              </button>
            </div>

            <div className="flex space-x-3">
              <button 
                onClick={() => setShowModal(false)}
                className="flex-1 text-gray-400 text-sm hover:text-white transition-colors"
              >
                稍后决定
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
