
import { useState, useEffect } from 'react';

export default function LandingPage() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentRewardSlide, setCurrentRewardSlide] = useState(0);
  const [showChat, setShowChat] = useState(false);
  const [uploadedImages, setUploadedImages] = useState(0);
  const [messages, setMessages] = useState([]);
  const [messageInput, setMessageInput] = useState('');
  const [showCopyPopup, setShowCopyPopup] = useState(false);
  const [config, setConfig] = useState<any>(null);

  // 从localStorage加载配置
  useEffect(() => {
    const loadConfig = () => {
      const savedConfig = localStorage.getItem('adminConfig');
      if (savedConfig) {
        try {
          const parsedConfig = JSON.parse(savedConfig);
          setConfig(parsedConfig);
          // 设置初始欢迎消息
          setMessages([
            {
              type: 'bot',
              content: parsedConfig.landing.chatBotWelcome,
              avatar: parsedConfig.landing.chatBotAvatar
            }
          ]);
        } catch (error) {
          console.error('配置解析错误:', error);
          loadDefaultConfig();
        }
      } else {
        loadDefaultConfig();
      }
    };

    const loadDefaultConfig = () => {
      const defaultConfig = {
        landing: {
          title: '免费领取资源教程',
          subtitle: '简单几步即可领取资源',
          taskNote: '我们整理了全网同人动漫、黑白彩色漫画,动漫新番、3d同人绅士手游 全部免费!\n资源整合不易,免费分享给大家,所以请大家帮忙宣传一下,设置了一个非常简单的小任务(30秒就可以搞底)\n你可以免费得到同人动漫+漫画800G,+JM软件+多款3d同人绅士手游 免费畅玩!',
          buyButtonText: '🛒 直接购买',
          buyButtonUrl: 'https://czt.pics/tuhao/zx.html',
          steps: {
            step1: {
              title: '第一步',
              description: '打开抖音/快手/B站/小红书搜索下面其中一个关键词【点击复制】↓↓',
              keywords: ['同人动漫', '火影同人', '同人', '漫画推荐', '二次元同人', '国漫女神'],
              additionalNote: '或者去搜你想看的动漫或本子或游戏名字,只要相关的视频都可以评论'
            },
            step2: {
              title: '第二步',
              description: '随机复制下面 其中一句 文案去抖音/快手/B站/小红书评论:【点击复制】',
              comments: [
                '这是我的乐园\n记得每天坚持打卡mxt.hair\n基本每天都会看看',
                '用三五年了都mxt.hair\n不用太客气',
                '可以の没啥毛病\nmxt.hair每天打卡就是\n你这聪明的脑袋瓜子'
              ]
            },
            step3: {
              title: '第三步',
              description: '打开抖音/快手/B站/小红书搜索关键词,搜索后往下滑,选4个相关的视频!\n评论上面刚保存的文案,每个视频评论一次\n最后给自己的评论点个赞 ,并截图',
              finalNote: '将你刚评论的截图发给右下侧的 AI机器人',
              demoImages: [
                'https://xxn.lol/images/最新示范.jpg',
                'https://xxn.lol/img/宣传图.jpg'
              ],
              demoTitle: '👇如下图所示👇',
              finalStepTitle: '最后一步',
              finalDescription: '机器人会在(10)秒内审核完,然后会在聊天框自动弹出所有资源的跳转网盘链接',
              warningText: '注意:不规范截图和上传重复截图将重置进度!',
              exampleText: '已完成示例:👇👇👇'
            }
          },
          slides: [
            'https://xxn.lol/img/1.jpg',
            'https://xxn.lol/img/2.jpg',
            'https://xxn.lol/img/3.jpg',
            'https://xxn.lol/img/4.jpg',
            'https://xxn.lol/img/5.jpg',
            'https://xxn.lol/img/6.png',
            'https://xxn.lol/img/7.jpg',
            'https://xxn.lol/img/8.jpg'
          ],
          rewardSlides: [
            'https://xxn.lol/img/c1.png',
            'https://xxn.lol/img/c2.jpg'
          ],
          chatBotName: 'AI机器人',
          chatBotAvatar: 'https://xxn.lol/img/头像.png',
          chatBotWelcome: '请将评论的规范截图都发送给我\n审核通过后我会发送所有资源的跳转页链接~\n注意:不规范截图和发送重复的截图将重置进度,所以是一定不能投机取巧的哦!',
          customReply: '🎉 恭喜您完成所有任务！\n\n您已成功上传3张评论截图，审核全部通过！\n\n现在为您提供所有资源下载链接：\n\n📚 同人动漫合集：https://pan.baidu.com/xxx\n📖 漫画资源包：https://pan.baidu.com/xxx\n🎮 3D同人游戏：https://pan.baidu.com/xxx\n💎 JM软件：https://pan.baidu.com/xxx\n\n感谢您的支持！请保存好这些链接。'
        }
      };
      setConfig(defaultConfig);
      setMessages([
        {
          type: 'bot',
          content: defaultConfig.landing.chatBotWelcome,
          avatar: defaultConfig.landing.chatBotAvatar
        }
      ]);
    };

    loadConfig();

    // 监听localStorage变化，实时更新配置
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'adminConfig' && e.newValue) {
        try {
          const newConfig = JSON.parse(e.newValue);
          setConfig(newConfig);
        } catch (error) {
          console.error('配置更新错误:', error);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    
    // 定期检查配置更新（解决同一标签页内的更新）
    const configCheckInterval = setInterval(() => {
      const currentConfig = localStorage.getItem('adminConfig');
      if (currentConfig) {
        try {
          const newConfig = JSON.parse(currentConfig);
          setConfig(newConfig);
        } catch (error) {
          console.error('配置检查错误:', error);
        }
      }
    }, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(configCheckInterval);
    };
  }, []);


  useEffect(() => {
    if (config?.landing?.slides) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % config.landing.slides.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [config?.landing?.slides]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setShowCopyPopup(true);
    setTimeout(() => setShowCopyPopup(false), 2000);
  };

  const handleSlideChange = (direction: number) => {
    if (!config?.landing?.slides) return;
    setCurrentSlide((prev) => {
      const newSlide = prev + direction;
      if (newSlide < 0) return config.landing.slides.length - 1;
      if (newSlide >= config.landing.slides.length) return 0;
      return newSlide;
    });
  };

  const handleRewardSlideChange = (direction: number) => {
    if (!config?.landing?.rewardSlides) return;
    setCurrentRewardSlide((prev) => {
      const newSlide = prev + direction;
      if (newSlide < 0) return config.landing.rewardSlides.length - 1;
      if (newSlide >= config.landing.rewardSlides.length) return 0;
      return newSlide;
    });
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const newMessage = {
          type: 'user',
          content: '[图片]',
          image: e.target?.result as string
        };
        setMessages(prev => [...prev, newMessage]);

        // 更新上传图片数量
        const newCount = uploadedImages + 1;
        setUploadedImages(newCount);

        // 根据上传数量给出不同回复
        setTimeout(() => {
          let botReplyContent = '';

          if (newCount < 3) {
            botReplyContent = `图片上传成功，审核通过！\\n\\n当前已上传 ${newCount} 张图片，请继续上传剩余 ${3 - newCount} 张图片。\\n\\n继续加油！完成后即可获得所有资源。`;
          } else if (newCount === 3) {
            botReplyContent = config?.landing?.customReply || '任务完成！';
          }

          const botReply = {
            type: 'bot',
            content: botReplyContent,
            avatar: config?.landing?.chatBotAvatar
          };
          setMessages(prev => [...prev, botReply]);
        }, 1000);
      };
      reader.readAsDataURL(file);
    }
  };

  const sendMessage = () => {
    if (messageInput.trim()) {
      const newMessage = {
        type: 'user',
        content: messageInput
      };
      setMessages(prev => [...prev, newMessage]);
      setMessageInput('');
    }
  };

  if (!config) {
    return <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="text-center">
        <div className="text-lg">加载中...</div>
      </div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold text-center mb-4">{config.landing.title}</h1>

          {/* Developer Note */}
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6">
            <div className="flex items-center mb-2">
              <div className="w-6 h-6 bg-blue-400 rounded-full mr-2"></div>
              <span className="font-semibold text-blue-800">{config.landing.subtitle}</span>
            </div>
            <div className="text-gray-700">
              <div className="whitespace-pre-line">
                <strong>{config.landing.taskNote}</strong>
              </div>
              <div className="mt-2">
                <span>⭐ 不想做任务的土豪,也可以直接进付费 ⭐</span>
              </div>
              <div className="mt-4">
                <a
                  href="/payment"
                  className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-full inline-flex items-center"
                >
                  {config.landing.buyButtonText}
                </a>
              </div>
            </div>
          </div>

          {/* Slideshow */}
          <div className="relative mb-8">
            <div className="relative h-80 bg-black rounded-lg overflow-hidden">
              {config.landing.slides.map((slide: string, index: number) => (
                <img
                  key={index}
                  src={slide}
                  alt={`Slide ${index + 1}`}
                  className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
                />
              ))}
              <button
                onClick={() => handleSlideChange(-1)}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white text-2xl hover:bg-black/50 w-10 h-10 rounded-full flex items-center justify-center"
              >
                ❮
              </button>
              <button
                onClick={() => handleSlideChange(1)}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white text-2xl hover:bg-black/50 w-10 h-10 rounded-full flex items-center justify-center"
              >
                ❯
              </button>
            </div>
            <div className="flex justify-center mt-4 space-x-2">
              {config.landing.slides.map((_: any, index: number) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 rounded-full ${index === currentSlide ? 'bg-blue-500' : 'bg-gray-300'}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Steps */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Step 1 */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold mr-3">1</div>
            <h3 className="text-xl font-bold">{config.landing.steps.step1.title}</h3>
          </div>
          <p className="mb-4">
            <strong>{config.landing.steps.step1.description}</strong>
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            {config.landing.steps.step1.keywords.map((keyword: string, index: number) => (
              <button
                key={index}
                onClick={() => copyToClipboard(keyword)}
                className="bg-blue-100 hover:bg-blue-200 text-blue-800 px-4 py-2 rounded-lg font-medium transition-colors"
                title="点击复制关键词"
              >
                {keyword}
              </button>
            ))}
          </div>
          {config.landing.steps.step1.additionalNote && (
            <p className="text-gray-600">
              <strong>{config.landing.steps.step1.additionalNote}</strong>
            </p>
          )}
        </div>

        {/* Step 2 */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold mr-3">2</div>
            <h3 className="text-xl font-bold">{config.landing.steps.step2.title}</h3>
          </div>
          <p className="mb-4">
            <strong>{config.landing.steps.step2.description}</strong>
          </p>
          <div className="space-y-3">
            {config.landing.steps.step2.comments.map((comment: string, index: number) => (
              <button
                key={index}
                onClick={() => copyToClipboard(comment)}
                className="block w-full bg-blue-100 hover:bg-blue-200 text-blue-800 px-4 py-3 rounded-lg text-left transition-colors"
              >
                {comment.split('\\n').map((line: string, i: number) => (
                  <div key={i}>{line}</div>
                ))}
              </button>
            ))}
          </div>
        </div>

        {/* Step 3 */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold mr-3">3</div>
            <h3 className="text-xl font-bold">{config.landing.steps.step3.title}</h3>
          </div>
          <div className="mb-4 whitespace-pre-line">
            <p><strong>{config.landing.steps.step3.description}</strong></p>
          </div>
          {config.landing.steps.step3.demoTitle && (
            <div className="text-center">
              <strong className="text-red-600 text-lg">{config.landing.steps.step3.demoTitle}</strong>
            </div>
          )}
          <div className="mt-4 space-y-4">
            {config.landing.steps.step3.demoImages ? 
              config.landing.steps.step3.demoImages.map((imageUrl: string, index: number) => (
                <img key={index} src={imageUrl} alt={`示范图${index + 1}`} className="w-full rounded-lg" />
              )) : 
              <>
                <img src="https://xxn.lol/images/最新示范.jpg" alt="示范图" className="w-full rounded-lg" />
                <img src="https://xxn.lol/img/宣传图.jpg" alt="宣传图" className="w-full rounded-lg" />
              </>
            }
          </div>
        </div>

        {/* Final Step */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="text-center mb-4">
            <h3 className="text-xl font-bold text-green-600">
              {config.landing.steps.step3.finalStepTitle || '最后一步'}
            </h3>
          </div>
          <div className="text-center mb-6">
            <p className="mb-4">
              <strong>{config.landing.steps.step3.finalNote}</strong>
            </p>
            {config.landing.steps.step3.finalDescription && (
              <p className="mb-4">{config.landing.steps.step3.finalDescription}</p>
            )}
            {config.landing.steps.step3.warningText && (
              <p className="text-red-600 font-bold">{config.landing.steps.step3.warningText}</p>
            )}
            {config.landing.steps.step3.exampleText && (
              <p className="mt-4 font-bold">{config.landing.steps.step3.exampleText}</p>
            )}
          </div>

          {/* Reward Slideshow */}
          <div className="relative">
            <div className="relative bg-gray-200 rounded-lg overflow-hidden">
              {config.landing.rewardSlides.map((slide: string, index: number) => (
                <img
                  key={index}
                  src={slide}
                  alt={`Reward ${index + 1}`}
                  className={`w-full object-contain transition-opacity duration-500 ${index === currentRewardSlide ? 'opacity-100' : 'opacity-0 absolute inset-0'}`}
                  style={{ aspectRatio: 'auto' }}
                />
              ))}
              <button
                onClick={() => handleRewardSlideChange(-1)}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white text-2xl hover:bg-black/50 w-10 h-10 rounded-full flex items-center justify-center"
              >
                ❮
              </button>
              <button
                onClick={() => handleRewardSlideChange(1)}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white text-2xl hover:bg-black/50 w-10 h-10 rounded-full flex items-center justify-center"
              >
                ❯
              </button>
            </div>
            <div className="flex justify-center mt-4 space-x-2">
              {config.landing.rewardSlides.map((_: any, index: number) => (
                <button
                  key={index}
                  onClick={() => setCurrentRewardSlide(index)}
                  className={`w-3 h-3 rounded-full ${index === currentRewardSlide ? 'bg-blue-500' : 'bg-gray-300'}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Floating Chat Button */}
      <div
        className="fixed bottom-4 right-4 bg-blue-500 text-white rounded-full p-3 cursor-pointer hover:bg-blue-600 transition-colors shadow-lg z-50"
        onClick={() => setShowChat(!showChat)}
      >
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 bg-white/20 rounded-full"></div>
          <span className="text-sm font-medium">{config.landing.chatBotName}</span>
          <span className="text-lg">▶</span>
        </div>
      </div>

      {/* Chat Window */}
      {showChat && (
        <div className="fixed bottom-20 right-4 w-80 h-96 bg-white rounded-lg shadow-xl z-50 flex flex-col">
          {/* Chat Header */}
          <div className="bg-blue-500 text-white p-3 rounded-t-lg flex justify-between items-center">
            <div>
              <div className="font-medium">{config.landing.chatBotName}</div>
              <div className="text-sm opacity-90">审核员;小雨 - 在线中</div>
            </div>
            <button
              onClick={() => setShowChat(false)}
              className="text-white hover:bg-blue-600 w-6 h-6 rounded flex items-center justify-center"
            >
              ✕
            </button>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map((message: any, index: number) => (
              <div key={index} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xs ${message.type === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-100'} rounded-lg p-3`}>
                  {message.image ? (
                    <img src={message.image} alt="Uploaded" className="w-full rounded" />
                  ) : (
                    <div className="whitespace-pre-line text-sm">{message.content}</div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="p-3 border-t">
            <div className="flex space-x-2 mb-2">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="imageUpload"
              />
              <label
                htmlFor="imageUpload"
                className="bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded text-sm cursor-pointer"
              >
                📷
              </label>
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="👈︎ 评论截图发送"
                className="flex-1 border rounded px-3 py-1 text-sm"
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              />
              <button
                onClick={sendMessage}
                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded text-sm"
              >
                发送
              </button>
            </div>
            <div className="flex space-x-2">
              <button className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm flex-1">
                打开快手
              </button>
              <button className="bg-pink-500 hover:pink-600 text-white px-3 py-1 rounded text-sm flex-1">
                打开抖音
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Copy Popup */}
      {showCopyPopup && (
        <div className="fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg z-50">
          文案已复制剪贴板
        </div>
      )}
    </div>
  );
}
