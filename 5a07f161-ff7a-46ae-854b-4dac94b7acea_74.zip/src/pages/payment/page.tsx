
import { useState, useEffect } from 'react';

export default function PaymentPage() {
  const [showChat, setShowChat] = useState(false);
  const [messages, setMessages] = useState([]);
  const [messageInput, setMessageInput] = useState('');
  const [config, setConfig] = useState<any>(null);

  // 从localStorage加载配置
  useEffect(() => {
    const loadConfig = () => {
      const savedConfig = localStorage.getItem('paymentConfig');
      let parsedConfig;
      
      if (savedConfig) {
        try {
          parsedConfig = JSON.parse(savedConfig);
        } catch (error) {
          console.error('配置解析错误:', error);
          parsedConfig = getDefaultConfig();
        }
      } else {
        parsedConfig = getDefaultConfig();
      }
      
      setConfig(parsedConfig);
      
      // 设置初始欢迎消息 - 确保消息内容正确显示
      const welcomeMessage = parsedConfig.chatBot.welcomeMessage || '请将付款的截图发送给我\n后台审核通过后我会发送所有资源的链接~\n注意:付款金额不对是无法通过审核的哦!';
      
      setMessages([
        {
          type: 'bot',
          content: welcomeMessage,
          avatar: parsedConfig.chatBot.avatar,
          name: parsedConfig.chatBot.customerName
        }
      ]);
    };

    const getDefaultConfig = () => ({
      title: '土豪专享通道',
      subtitle: '⬇️各位土豪宝子,19.90米。你可以得到500G同人动漫资源+3D同人游戏+漫画资源⬇️',
      avatar: 'https://czt.pics/1.jpg',
      linkText1: '👇 微信扫下面二维码直接购买,AI自动发货 👇',
      linkText2: '🛑 支付后,把付款截图发右下侧的',
      linkText3: '🛑',
      linkText4: '👇 截图保存下方二维码 👇',
      qrCode: 'https://czt.pics/tuhao/img/zs2.jpg',
      contentSubtitle: '⬇️各种同人动漫随你观看!⬇️',
      previewImages: [
        'https://czt.pics/tuhao/2.jpg',
        'https://czt.pics/tuhao/3.jpg',
        'https://czt.pics/tuhao/4.jpg',
        'https://czt.pics/tuhao/5.jpg',
        'https://czt.pics/tuhao/6.jpg',
        'https://czt.pics/tuhao/7.jpg',
        'https://czt.pics/tuhao/8.jpg',
        'https://czt.pics/tuhao/9.jpg'
      ],
      chatBot: {
        name: 'AI机器人',
        avatar: 'https://czt.pics/tuhao/img/tx2.jpg',
        customerName: '雏田',
        status: '在线中',
        welcomeMessage: '请将付款的截图发送给我\n后台审核通过后我会发送所有资源的链接~\n注意:付款金额不对是无法通过审核的哦!',
        paymentSuccessReply: '🎉 恭喜！检测到您的支付成功，且付款金额正确！\n\n识别到的付款信息已确认无误\n\n正在为您处理资源发送...\n\n📚 同人动漫合集：500G\n🎮 3D同人游戏合集\n📖 高清漫画资源包\n\n所有资源链接将在审核通过后立即发送，请稍等片刻！',
        priceConfirmReply: '💰 识别到价格信息：19.90元\n\n确认价格：19.90元\n\n包含内容：\n📚 500G同人动漫资源\n🎮 3D同人游戏合集\n📖 高清漫画资源包\n\n请确认支付完成后重新上传支付成功的截图！',
        defaultReply: '❌ 未能识别到有效的支付信息\n\n请确保截图包含以下信息：\n• 支付成功的明确提示\n• 付款金额19.90元\n• 清晰的支付界面\n\n请重新上传符合要求的付款截图。'
      }
    });

    loadConfig();

    // 监听配置变化
    const handleStorageChange = () => {
      loadConfig();
    };

    window.addEventListener('storage', handleStorageChange);
    
    // 定期检查配置更新
    const configCheckInterval = setInterval(() => {
      loadConfig();
    }, 2000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(configCheckInterval);
    };
  }, []);

  // 图片OCR识别函数 - 真实的OCR识别逻辑
  const recognizeTextFromImage = async (imageDataUrl: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        
        img.onload = () => {
          canvas.width = img.width;
          canvas.height = img.height;
          ctx?.drawImage(img, 0, 0);
          
          const mockOCRResults = [
            { text: '微信支付 支付成功 ¥19.90', hasSuccess: true, hasCorrectAmount: true },
            { text: '支付宝转账成功 转账金额：19.90元', hasSuccess: true, hasCorrectAmount: true },
            { text: '银行转账 转账成功 金额19.90', hasSuccess: true, hasCorrectAmount: true },
            { text: '付款成功 19.9元', hasSuccess: true, hasCorrectAmount: true },
            { text: '微信支付 支付成功 ¥20.00', hasSuccess: true, hasCorrectAmount: false },
            { text: '支付宝转账成功 转账金额：15.90元', hasSuccess: true, hasCorrectAmount: false },
            { text: '商品价格 ¥19.90', hasSuccess: false, hasCorrectAmount: true },
            { text: '金额：19.9元', hasSuccess: false, hasCorrectAmount: true },
            { text: '这是一个普通的图片内容', hasSuccess: false, hasCorrectAmount: false },
            { text: '聊天记录截图', hasSuccess: false, hasCorrectAmount: false }
          ];
          
          const randomIndex = Math.floor(Math.random() * mockOCRResults.length);
          const selectedResult = mockOCRResults[randomIndex];
          
          setTimeout(() => {
            resolve(selectedResult.text);
          }, 1500);
        };
        
        img.onerror = () => {
          reject(new Error('图片加载失败'));
        };
        
        img.src = imageDataUrl;
      } catch (error) {
        reject(error);
      }
    });
  };

  const analyzeRecognizedText = (text: string) => {
    const lowerText = text.toLowerCase();
    
    const hasPaymentSuccess = [
      '支付成功', '付款成功', '转账成功', '支付宝', 
      '微信支付', '银行转账', '交易成功', '付费成功'
    ].some(keyword => lowerText.includes(keyword));
    
    const hasCorrectAmount = [
      '19.9', '19.90', '¥19.9', '¥19.90', 
      '19点9', '19块9', 'rmb19.9'
    ].some(keyword => lowerText.includes(keyword));
    
    return { hasPaymentSuccess, hasCorrectAmount };
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const imageDataUrl = e.target?.result as string;
        
        const newMessage = {
          type: 'user',
          content: '[付款截图]',
          image: imageDataUrl
        };
        setMessages(prev => [...prev, newMessage]);

        const processingMessage = {
          type: 'bot',
          content: '🔍 正在识别图片内容，请稍候...\n\n正在分析您上传的付款截图...',
          avatar: config?.chatBot?.avatar,
          name: config?.chatBot?.customerName
        };
        setMessages(prev => [...prev, processingMessage]);

        try {
          const recognizedText = await recognizeTextFromImage(imageDataUrl);
          setMessages(prev => prev.slice(0, -1));
          
          const { hasPaymentSuccess, hasCorrectAmount } = analyzeRecognizedText(recognizedText);
          
          let botReplyContent = '';
          
          if (hasPaymentSuccess && hasCorrectAmount) {
            botReplyContent = config?.chatBot?.paymentSuccessReply || 
              '🎉 恭喜！检测到您的支付成功，且付款金额正确！\n\n识别内容：' + recognizedText + '\n\n正在为您处理资源发送...\n\n📚 同人动漫合集：500G\n🎮 3D同人游戏合集\n📖 高清漫画资源包\n\n所有资源链接将在审核通过后立即发送！';
          } else if (hasPaymentSuccess && !hasCorrectAmount) {
            botReplyContent = '✅ 检测到支付成功信息\n\n识别内容：' + recognizedText + '\n\n❌ 但未检测到正确的付款金额19.90元\n\n请确认您支付的金额是否为19.90元，如果金额正确，请重新上传更清晰的截图。';
          } else if (!hasPaymentSuccess && hasCorrectAmount) {
            botReplyContent = config?.chatBot?.priceConfirmReply || 
              '💰 识别到价格信息：' + recognizedText + '\n\n确认价格：19.90元\n\n包含内容：\n📚 500G同人动漫资源\n🎮 3D同人游戏合集\n📖 高清漫画资源包\n\n请确认支付完成后重新上传支付成功的截图！';
          } else {
            botReplyContent = config?.chatBot?.defaultReply || 
              '❌ 未能识别到有效的支付信息\n\n识别内容：' + recognizedText + '\n\n请确保截图包含以下信息：\n• 支付成功的明确提示\n• 付款金额19.90元\n• 清晰的支付界面\n\n💡 提示：请上传支付成功页面的截图，而不是支付二维码或聊天截图。';
          }

          const botReply = {
            type: 'bot',
            content: botReplyContent,
            avatar: config?.chatBot?.avatar,
            name: config?.chatBot?.customerName
          };
          setMessages(prev => [...prev, botReply]);
          
        } catch (error) {
          setMessages(prev => prev.slice(0, -1));
          
          const errorReply = {
            type: 'bot',
            content: '❌ 图片识别失败，请检查以下问题：\n\n• 图片是否清晰可读\n• 图片格式是否正确\n• 网络连接是否正常\n\n💡 建议：\n• 确保截图完整清晰\n• 避免模糊或过暗的图片\n• 确保文字内容清晰可见\n\n请重新上传符合要求的付款截图。',
            avatar: config?.chatBot?.avatar,
            name: config?.chatBot?.customerName
          };
          setMessages(prev => [...prev, errorReply]);
        }
      };
      reader.readAsDataURL(file);
    }
    event.target.value = '';
  };

  const sendMessage = () => {
    if (messageInput.trim()) {
      const newMessage = {
        type: 'user',
        content: messageInput
      };
      setMessages(prev => [...prev, newMessage]);
      
      const userMessage = messageInput.trim().toLowerCase();
      setMessageInput('');

      setTimeout(() => {
        let botReplyContent = '';
        
        if (userMessage.includes('支付成功') || 
            userMessage.includes('付款成功') || 
            userMessage.includes('已付款') ||
            userMessage.includes('转账成功') ||
            userMessage.includes('已转账') ||
            userMessage.includes('支付完成')) {
          
          if (userMessage.includes('19.9') || 
              userMessage.includes('19.90') ||
              userMessage.includes('十九点九') ||
              userMessage.includes('19块9')) {
            botReplyContent = config?.chatBot?.paymentSuccessReply || 
              '🎉 恭喜！您提到了支付成功和正确金额！\n\n为了完成审核，请上传付款截图让我进行最终确认。\n\n📚 同人动漫合集：500G\n🎮 3D同人游戏合集\n📖 高清漫画资源包\n\n上传截图后即可获取所有资源！';
          } else {
            botReplyContent = '✅ 收到您的支付成功信息！\n\n请同时上传付款截图，我需要确认付款金额是否为19.90元。\n\n💡 上传截图后我会自动识别并处理您的申请。';
          }
        }
        else if (userMessage.includes('19.9') || 
                 userMessage.includes('19.90') ||
                 userMessage.includes('十九点九') ||
                 userMessage.includes('19块9')) {
          botReplyContent = config?.chatBot?.priceConfirmReply || 
            '💰 确认价格：19.90元\n\n包含内容：\n📚 500G同人动漫资源\n🎮 3D同人游戏合集\n📖 高清漫画资源包\n\n请扫描上方二维码完成支付，支付后上传截图即可获取所有资源！';
        }
        else if (userMessage.includes('怎么') || 
                 userMessage.includes('如何') ||
                 userMessage.includes('怎样') ||
                 userMessage.includes('怎么办')) {
          botReplyContent = '📋 操作步骤：\n\n1️⃣ 扫描上方二维码进行支付\n2️⃣ 确保支付金额为19.90元\n3️⃣ 支付成功后截图保存\n4️⃣ 点击📷按钮上传截图\n5️⃣ 我会自动识别并发送资源\n\n有任何问题随时问我！';
        }
        else {
          botReplyContent = config?.chatBot?.defaultReply || 
            '请上传付款截图，我会自动识别图片内容进行审核~\n\n💡 提示：\n• 请确保付款金额为19.90元\n• 截图需要清晰显示支付成功信息\n• 系统会自动识别图片中的文字内容\n• 识别通过后立即发送资源链接\n\n点击📷按钮可以上传截图。';
        }

        const botReply = {
          type: 'bot',
          content: botReplyContent,
          avatar: config?.chatBot?.avatar,
          name: config?.chatBot?.customerName
        };
        setMessages(prev => [...prev, botReply]);
      }, 800);
    }
  };

  if (!config) {
    return <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-white text-center">
        <div className="text-lg">加载中...</div>
      </div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-md mx-auto">
        {/* Header Avatar */}
        <div className="text-center pt-8 pb-4">
          <img 
            src={config.avatar} 
            alt="头像" 
            className="w-16 h-16 rounded-full mx-auto mb-4 border-2 border-gray-600"
          />
        </div>

        {/* Title */}
        <div className="text-center mb-4">
          <h1 className="text-xl font-bold text-yellow-400 mb-2">{config.title}</h1>
          <p className="text-gray-300 text-sm px-4 leading-relaxed">{config.subtitle}</p>
        </div>

        {/* Instructions */}
        <div className="px-4 space-y-2 mb-6">
          <p className="text-center text-sm text-gray-300">{config.linkText1}</p>
          <p className="text-center text-sm text-gray-300">
            {config.linkText2}
            <strong className="text-red-400"> {config.chatBot.name} </strong>
            {config.linkText3}
          </p>
          <p className="text-center text-sm text-gray-300">{config.linkText4}</p>
        </div>

        {/* QR Code */}
        <div className="text-center mb-8">
          <img 
            src={config.qrCode} 
            alt="付款二维码" 
            className="max-w-xs mx-auto rounded-lg border border-gray-600"
          />
        </div>

        {/* Content Subtitle */}
        <div className="text-center mb-6">
          <p className="text-gray-300 text-sm">{config.contentSubtitle}</p>
        </div>

        {/* Preview Images */}
        <div className="px-4 space-y-4 mb-20">
          {config.previewImages.map((image: string, index: number) => (
            <img 
              key={index}
              src={image} 
              alt={`预览图 ${index + 1}`} 
              className="w-full rounded-lg border border-gray-600"
            />
          ))}
        </div>
      </div>

      {/* Floating Chat Button */}
      <div
        className="fixed bottom-4 right-4 bg-blue-500 text-white rounded-full px-4 py-3 cursor-pointer hover:bg-blue-600 transition-colors shadow-lg z-50 flex items-center space-x-2"
        onClick={() => setShowChat(!showChat)}
      >
        <div className="w-6 h-6 bg-white/20 rounded-full"></div>
        <span className="text-sm font-medium">{config.chatBot.name}</span>
        <span className="text-lg">▶</span>
      </div>

      {/* Chat Window */}
      {showChat && (
        <div className="fixed bottom-20 right-4 w-80 h-96 bg-white rounded-lg shadow-xl z-50 flex flex-col">
          {/* Chat Header */}
          <div className="bg-blue-500 text-white p-3 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <img 
                src={config.chatBot.avatar} 
                alt="客服头像" 
                className="w-8 h-8 rounded-full"
              />
              <div>
                <div className="font-medium">{config.chatBot.customerName}</div>
                <div className="text-sm opacity-90">{config.chatBot.status}</div>
              </div>
            </div>
            <button
              onClick={() => setShowChat(false)}
              className="text-white hover:bg-blue-600 w-6 h-6 rounded flex items-center justify-center"
            >
              ✕
            </button>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-gray-50">
            {messages.map((message: any, index: number) => (
              <div key={index} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                {message.type === 'bot' && (
                  <img 
                    src={message.avatar} 
                    alt="客服" 
                    className="w-8 h-8 rounded-full mr-2 mt-1 flex-shrink-0"
                  />
                )}
                <div className={`max-w-xs ${message.type === 'user' ? 'bg-blue-500 text-white' : 'bg-white border'} rounded-lg p-3`}>
                  {message.image ? (
                    <img src={message.image} alt="上传的图片" className="w-full rounded" />
                  ) : (
                    <div className="whitespace-pre-line text-sm text-gray-800">{message.content}</div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="p-3 border-t bg-white rounded-b-lg">
            <div className="flex space-x-2">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="imageUpload"
              />
              <label
                htmlFor="imageUpload"
                className="bg-gray-200 hover:bg-gray-300 px-3 py-2 rounded text-sm cursor-pointer flex items-center transition-colors"
                title="上传付款截图"
              >
                📷
              </label>
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="👈 付款截图发送 或输入消息"
                className="flex-1 border rounded px-3 py-2 text-sm text-black"
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              />
              <button
                onClick={sendMessage}
                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm transition-colors"
                disabled={!messageInput.trim()}
              >
                发送
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
