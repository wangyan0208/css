
import { useState, useEffect } from 'react';

interface AdminConfig {
  // 登录页配置
  landing: {
    title: string;
    subtitle: string;
    taskNote: string;
    buyButtonText: string;
    buyButtonUrl: string;
    steps: {
      step1: {
        title: string;
        description: string;
        keywords: string[];
        additionalNote?: string;
      };
      step2: {
        title: string;
        description: string;
        comments: string[];
      };
      step3: {
        title: string;
        description: string;
        finalNote: string;
        demoImages: string[];
        demoTitle?: string;
        finalStepTitle?: string;
        finalDescription?: string;
        warningText?: string;
        exampleText?: string;
      };
    };
    slides: string[];
    rewardSlides: string[];
    chatBotName: string;
    chatBotAvatar: string;
    chatBotWelcome: string;
    customReply: string;
  };
  // 首页配置
  home: {
    title: string;
    categories: string[];
    videoSections: {
      title: string;
      videos: {
        title: string;
        duration: string;
        rating: string;
        thumbnail: string;
      }[];
    }[];
    footer: string;
    modalTitle: string;
    modalDescription: string;
    modalButtonText: string;
    // 新增预览图配置
    previewImages: {
      name: string;
      url: string;
    }[];
  };
  // 漫画页配置
  comic: {
    title: string;
    comics: {
      title: string;
      chapters: string;
      rating: string;
      thumbnail: string;
    }[];
    footer: string;
    modalTitle?: string;
    modalDescription?: string;
    modalButtonText?: string;
  };
  // 游戏页配置
  game: {
    title: string;
    games: {
      title: string;
      tag: string;
      mode: string;
      rating: string;
      thumbnail: string;
    }[];
    footer: string;
    modalTitle?: string;
    modalDescription?: string;
    modalButtonText?: string;
  };
  // 付费页配置
  payment: {
    title: string;
    subtitle: string;
    avatar: string;
    linkText1: string;
    linkText2: string;
    linkText3: string;
    linkText4: string;
    qrCode: string;
    contentSubtitle: string;
    previewImages: string[];
    chatBot: {
      name: string;
      avatar: string;
      customerName: string;
      status: string;
      welcomeMessage: string;
      paymentSuccessReply?: string;
      priceConfirmReply?: string;
      defaultReply?: string;
    };
  };
}

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('landing');
  const [config, setConfig] = useState<AdminConfig>({
    landing: {
      title: '免费领取资源教程',
      subtitle: '简单几步即可领取资源',
      taskNote: '我们整理了全网同人动漫、黑白彩色漫画,动漫新番、3d同人绅士手游 全部免费!\n资源整合不易,免费分享给大家,所以请大家帮忙宣传一下,设置了一个非常简单的小任务(30秒就可以搞底)\n你可以免费得到同人动漫+漫画800G,+JM软件+多款3d同人绅士手游 免费畅玩!',
      buyButtonText: '🛒 直接购买',
      buyButtonUrl: 'https://czt.pics/tuhao/zx.html',
      steps: {
        step1: {
          title: '第一步',
          description: '打开抖音/快手/B站/小红书搜索下面其中一个关键词【点击复制】↓↓',
          keywords: ['同人动漫', '火影同人', '同人', '漫画推荐', '二次元同人', '国漫女神'],
          additionalNote: '或者去搜你想看的动漫或本子或游戏名字,只要相关的视频都可以评论'
        },
        step2: {
          title: '第二步',
          description: '随机复制下面 其中一句 文案去抖音/快手/B站/小红书评论:【点击复制】',
          comments: [
            '这是我的乐园\n记得每天坚持打卡mxt.hair\n基本每天都会看看',
            '用三五年了都mxt.hair\n不用太客气',
            '可以の没啥毛病\nmxt.hair每天打卡就是\n你这聪明的脑袋瓜子'
          ]
        },
        step3: {
          title: '第三步',
          description: '打开抖音/快手/B站/小红书搜索关键词,搜索后往下滑,选4个相关的视频!\n评论上面刚保存的文案,每个视频评论一次\n最后给自己的评论点个赞 ,并截图',
          finalNote: '将你刚评论的截图发给右下侧的 AI机器人',
          demoImages: [
            'https://xxn.lol/images/最新示范.jpg',
            'https://xxn.lol/img/宣传图.jpg'
          ],
          demoTitle: '👇如下图所示👇',
          finalStepTitle: '最后一步',
          finalDescription: '机器人会在(10)秒内审核完,然后会在聊天框自动弹出所有资源的跳转网盘链接',
          warningText: '注意:不规范截图和上传重复截图将重置进度!',
          exampleText: '已完成示例:👇👇👇'
        }
      },
      slides: [
        'https://xxn.lol/img/1.jpg',
        'https://xxn.lol/img/2.jpg',
        'https://xxn.lol/img/3.jpg',
        'https://xxn.lol/img/4.jpg',
        'https://xxn.lol/img/5.jpg',
        'https://xxn.lol/img/6.png',
        'https://xxn.lol/img/7.jpg',
        'https://xxn.lol/img/8.jpg'
      ],
      rewardSlides: [
        'https://xxn.lol/img/c1.png',
        'https://xxn.lol/img/c2.jpg'
      ],
      chatBotName: 'AI机器人',
      chatBotAvatar: 'https://xxn.lol/img/头像.png',
      chatBotWelcome: '请将评论的规范截图都发送给我\n审核通过后我会发送所有资源的跳转页链接~\n注意:不规范截图和发送重复的截图将重置进度,所以是一定不能投机取巧的哦!',
      customReply: '🎉 恭喜您完成所有任务！\n\n您已成功上传3张评论截图，审核全部通过！\n\n现在为您提供所有资源下载链接：\n\n📚 同人动漫合集：https://pan.baidu.com/xxx\n📖 漫画资源包：https://pan.baidu.com/xxx\n🎮 3D同人游戏：https://pan.baidu.com/xxx\n💎 JM软件：https://pan.baidu.com/xxx\n\n感谢您的支持！请保存好这些链接。'
    },
    home: {
      title: '公益网站 全部免费',
      categories: ['动漫', '漫画', '游戏', '真人', '写真'],
      videoSections: [
        {
          title: '番漫同人',
          videos: [
            { title: '枫与铃1~3', duration: '58分钟', rating: '9.8', thumbnail: 'https://tcp.baby/static/images/1.jpg' },
            { title: '我的妈妈', duration: '21分钟', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/2.jpg' }
          ]
        }
      ],
      footer: '© 2025 漫画星球 · 专属于各位漫画迷的资源',
      modalTitle: '解锁更多动漫内容',
      modalDescription: '登录白嫖动漫/漫画/游戏/真人',
      modalButtonText: '稍后决定',
      previewImages: [
        { name: '枫与铃1~3', url: 'https://tcp.baby/static/images/1.jpg' },
        { name: '我的妈妈', url: 'https://tcp.baby/static/images/2.jpg' },
        { name: '约尔过家家', url: 'https://tcp.baby/static/images/3.jpg' },
        { name: '催眠指导', url: 'https://tcp.baby/static/images/4.jpg' },
        { name: '2B小姐姐', url: 'https://tcp.baby/static/images/5.jpg' },
        { name: '撤退的矮子', url: 'https://tcp.baby/static/images/6.jpg' },
        { name: '紫阳花', url: 'https://tcp.baby/static/images/7.jpg' },
        { name: '召唤魅魔', url: 'https://tcp.baby/static/images/8.jpg' }
      ]
    },

    comic: {
      title: '公益网站 全部免费',
      comics: [
        { title: '纲手的午休时间', chapters: '72话', rating: '9.8', thumbnail: 'https://tcp.baby/static/images/61.jpg' },
        { title: '雷影忍者', chapters: '10话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/62.jpg' },
        { title: '大理寺巡街使', chapters: '20话', rating: '9.5', thumbnail: 'https://tcp.baby/static/images/63.jpg' },
        { title: '哪吒-玉虚宫战役', chapters: '19话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/64.jpg' },
        { title: '哪吒-捆仙绳', chapters: '46话', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/65.jpg' },
        { title: '鸣人的妻子', chapters: '48话', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/66.jpg' },
        { title: 'S诱鸣人之术', chapters: '93话', rating: '9.6', thumbnail: 'https://tcp.baby/static/images/67.jpg' },
        { title: '杨玉环-上元灯会奇遇', chapters: '39话', rating: '9.8', thumbnail: 'https://tcp.baby/static/images/68.jpg' },
        { title: '小樱捆绑XX', chapters: '29话', rating: '9.3', thumbnail: 'https://tcp.baby/static/images/69.jpg' },
        { title: '甄姬与幼童', chapters: '47话', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/70.jpg' },
        { title: '北北北砂-合集', chapters: '99话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/71.jpg' },
        { title: '小乔NTR', chapters: '22话', rating: '9.6', thumbnail: 'https://tcp.baby/static/images/72.jpg' },
        { title: '小文姬的大人游戏', chapters: '13话', rating: '9.9', thumbnail: 'https://tcp.baby/static/images/73.jpg' },
        { title: '瑶的全收集之路', chapters: '68话', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/74.jpg' },
        { title: '大小姐的街边服务', chapters: '45话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/75.jpg' },
        { title: '王者-大话西游同人', chapters: '37话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/76.jpg' },
        { title: '长安之乱', chapters: '24话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/77.jpg' },
        { title: '镜的欢迎会', chapters: '34话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/78.jpg' },
        { title: '虞姬寝取', chapters: '54话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/79.jpg' },
        { title: '圣诞礼物', chapters: '73话', rating: '9.7', thumbnail: 'https://tcp.baby/static/images/80.jpg' }
      ],
      footer: '© 2025 漫画星球 · 专属于各位漫画迷的资源',
      modalTitle: '白嫖到底',
      modalDescription: '立即登录,畅享海量独家漫画',
      modalButtonText: '稍后决定'
    },
    game: {
      title: '公益网站 全部免费',
      games: [
        { title: '时间停止', tag: '角色扮演', mode: '多人', rating: '9.3', thumbnail: 'https://tcp.baby/static/images/81.jpg' },
        { title: '与纲手同居', tag: '动作', mode: '单人', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/82.jpg' },
        { title: '极品采花郎', tag: '动作', mode: '多人', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/83.jpg' },
        { title: '夜幕之花', tag: '动作', mode: '单人', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/84.jpg' },
        { title: '忍者后宫', tag: '动作', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/85.jpg' },
        { title: '隔壁的女主播', tag: '动作', mode: '单人', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/86.jpg' },
        { title: '教育女忍:最后的战争', tag: '动作', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/87.jpg' },
        { title: '火影:被诅咒的忍术', tag: '动作', mode: '单人', rating: '8.5', thumbnail: 'https://tcp.baby/static/images/88.jpg' },
        { title: '海贼传:路飞的艳遇', tag: '策略', mode: '多人', rating: '8.8', thumbnail: 'https://tcp.baby/static/images/89.jpg' },
        { title: '暗影刺客:复仇之路', tag: '动作', mode: '单人', rating: '9.1', thumbnail: 'https://tcp.baby/static/images/90.jpg' },
        { title: '龙之纪元:命运召唤', tag: '角色扮演', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/91.jpg' },
        { title: '未来都市:赛博朋克', tag: '冒险', mode: '单人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/92.jpg' },
        { title: '荒野求生:极限生存', tag: '冒险', mode: '多人', rating: '8.6', thumbnail: 'https://tcp.baby/static/images/93.jpg' },
        { title: '火影:女忍训练师', tag: '角色扮演', mode: '单人', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/94.jpg' },
        { title: '火影:学长的生活', tag: '竞速', mode: '多人', rating: '8.7', thumbnail: 'https://tcp.baby/static/images/95.jpg' },
        { title: '火影:忍者领主', tag: '策略', mode: '单人', rating: '9.1', thumbnail: 'https://tcp.baby/static/images/96.jpg' },
        { title: '火影:火影崛起', tag: '策略', mode: '多人', rating: '9.2', thumbnail: 'https://tcp.baby/static/images/97.jpg' },
        { title: '火影:火影人生', tag: '策略', mode: '单人', rating: '9.1', thumbnail: 'https://tcp.baby/static/images/98.jpg' },
        { title: '王者荣耀:峡谷传说', tag: '竞技', mode: '多人', rating: '9.5', thumbnail: 'https://tcp.baby/static/images/99.jpg' },
        { title: '原神:提瓦特大陆', tag: '冒险', mode: '单人', rating: '9.4', thumbnail: 'https://tcp.baby/static/images/100.jpg' }
      ],
      footer: '© 2025 漫画星球 · 专属于各位漫画迷的资源',
      modalTitle: '嘎嘎白嫖',
      modalDescription: '立即登录,享受海量独家游戏',
      modalButtonText: '稍后决定'
    },
    payment: {
      title: '土豪专享通道',
      subtitle: '⬇️各位土豪宝子,19.90米。你可以得到500G同人动漫资源+3D同人游戏+漫画资源⬇️',
      avatar: 'https://czt.pics/1.jpg',
      linkText1: '👇 微信扫下面二维码直接购买,AI自动发货 👇',
      linkText2: '🛑 支付后,把付款截图发右下侧的',
      linkText3: '🛑',
      linkText4: '👇 截图保存下方二维码 👇',
      qrCode: 'https://czt.pics/tuhao/img/zs2.jpg',
      contentSubtitle: '⬇️各种同人动漫随你观看!⬇️',
      previewImages: [
        'https://czt.pics/tuhao/2.jpg',
        'https://czt.pics/tuhao/3.jpg',
        'https://czt.pics/tuhao/4.jpg',
        'https://czt.pics/tuhao/5.jpg',
        'https://czt.pics/tuhao/6.jpg',
        'https://czt.pics/tuhao/7.jpg',
        'https://czt.pics/tuhao/8.jpg',
        'https://czt.pics/tuhao/9.jpg'
      ],
      chatBot: {
        name: 'AI机器人',
        avatar: 'https://czt.pics/tuhao/img/tx2.jpg',
        customerName: '雏田',
        status: '在线中',
        welcomeMessage: '请将付款的截图发送给我\n后台审核通过后我会发送所有资源的链接~\n注意:付款金额不对是无法通过审核的哦!'
      }
    }
  });
  const [savedMessage, setSavedMessage] = useState('');

  useEffect(() => {
    // 从localStorage加载配置
    const savedConfig = localStorage.getItem('adminConfig');
    const savedPaymentConfig = localStorage.getItem('paymentConfig');
    
    if (savedConfig) {
      const parsedConfig = JSON.parse(savedConfig);
      // 确保新添加的字段有默认值
      if (!parsedConfig.landing.steps.step3.demoImages) {
        parsedConfig.landing.steps.step3.demoImages = [
          'https://xxn.lol/images/最新示范.jpg',
          'https://xxn.lol/img/宣传图.jpg'
        ];
      }
      // 确保home配置中有previewImages字段
      if (!parsedConfig.home) {
        parsedConfig.home = {
          title: '公益网站 全部免费',
          categories: ['动漫', '漫画', '游戏', '真人', '写真'],
          videoSections: [],
          footer: '© 2025 漫画星球 · 专属于各位漫画迷的资源',
          modalTitle: '解锁更多动漫内容',
          modalDescription: '登录白嫖动漫/漫画/游戏/真人',
          modalButtonText: '稍后决定',
          previewImages: [
            { name: '枫与铃1~3', url: 'https://tcp.baby/static/images/1.jpg' },
            { name: '我的妈妈', url: 'https://tcp.baby/static/images/2.jpg' },
            { name: '约尔过家家', url: 'https://tcp.baby/static/images/3.jpg' },
            { name: '催眠指导', url: 'https://tcp.baby/static/images/4.jpg' },
            { name: '2B小姐姐', url: 'https://tcp.baby/static/images/5.jpg' },
            { name: '撤退的矮子', url: 'https://tcp.baby/static/images/6.jpg' },
            { name: '紫阳花', url: 'https://tcp.baby/static/images/7.jpg' },
            { name: '召唤魅魔', url: 'https://tcp.baby/static/images/8.jpg' }
          ]
        };
      }
      if (!parsedConfig.home.previewImages) {
        parsedConfig.home.previewImages = [
          { name: '枫与铃1~3', url: 'https://tcp.baby/static/images/1.jpg' },
          { name: '我的妈妈', url: 'https://tcp.baby/static/images/2.jpg' },
          { name: '约尔过家家', url: 'https://tcp.baby/static/images/3.jpg' },
          { name: '催眠指导', url: 'https://tcp.baby/static/images/4.jpg' },
          { name: '2B小姐姐', url: 'https://tcp.baby/static/images/5.jpg' },
          { name: '撤退的矮子', url: 'https://tcp.baby/static/images/6.jpg' },
          { name: '紫阳花', url: 'https://tcp.baby/static/images/7.jpg' },
          { name: '召唤魅魔', url: 'https://tcp.baby/static/images/8.jpg' }
        ];
      }
      setConfig(prev => ({ ...prev, ...parsedConfig }));
    }

    // 加载付费页配置
    if (savedPaymentConfig) {
      const parsedPaymentConfig = JSON.parse(savedPaymentConfig);
      setConfig(prev => ({ ...prev, payment: parsedPaymentConfig }));
    }
  }, []);

  const saveConfig = () => {
    localStorage.setItem('adminConfig', JSON.stringify({
      landing: config.landing,
      home: config.home,
      comic: config.comic,
      game: config.game
    }));
    
    // 单独保存付费页配置
    localStorage.setItem('paymentConfig', JSON.stringify(config.payment));
    
    setSavedMessage('配置已保存！');
    setTimeout(() => setSavedMessage(''), 3000);
  };

  const updateConfig = (path: string[], value: any) => {
    setConfig(prev => {
      const newConfig = { ...prev };
      let current: any = newConfig;
      for (let i = 0; i < path.length - 1; i++) {
        current = current[path[i]];
      }
      current[path[path.length - 1]] = value;
      return newConfig;
    });
  };

  const addArrayItem = (path: string[], item: any) => {
    setConfig(prev => {
      const newConfig = { ...prev };
      let current: any = newConfig;
      for (const key of path) {
        current = current[key];
      }
      current.push(item);
      return newConfig;
    });
  };

  const removeArrayItem = (path: string[], index: number) => {
    setConfig(prev => {
      const newConfig = { ...prev };
      let current: any = newConfig;
      for (const key of path) {
        current = current[key];
      }
      current.splice(index, 1);
      return newConfig;
    });
  };

  // 新增：图片本地上传处理函数
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>, path: string[], index?: number) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageDataUrl = e.target?.result as string;
        
        if (index !== undefined) {
          // 更新数组中的特定图片
          setConfig(prev => {
            const newConfig = { ...prev };
            let current: any = newConfig;
            for (const key of path) {
              current = current[key];
            }
            current[index] = imageDataUrl;
            return newConfig;
          });
        } else {
          // 添加新图片到数组
          addArrayItem(path, imageDataUrl);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const renderLandingConfig = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">页面标题</label>
        <input
          type="text"
          value={config.landing.title}
          onChange={(e) => updateConfig(['landing', 'title'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">副标题</label>
        <input
          type="text"
          value={config.landing.subtitle}
          onChange={(e) => updateConfig(['landing', 'subtitle'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">任务说明</label>
        <textarea
          value={config.landing.taskNote}
          onChange={(e) => updateConfig(['landing', 'taskNote'], e.target.value)}
          className="w-full border rounded px-3 py-2 h-32"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">购买按钮文字</label>
        <input
          type="text"
          value={config.landing.buyButtonText}
          onChange={(e) => updateConfig(['landing', 'buyButtonText'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">购买链接</label>
        <input
          type="text"
          value={config.landing.buyButtonUrl}
          onChange={(e) => updateConfig(['landing', 'buyButtonUrl'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      {/* 第一步配置 */}
      <div className="border rounded p-4 bg-gray-50">
        <h3 className="text-lg font-medium mb-4">第一步配置</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">步骤标题</label>
            <input
              type="text"
              value={config.landing.steps.step1.title}
              onChange={(e) => updateConfig(['landing', 'steps', 'step1', 'title'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">步骤描述</label>
            <textarea
              value={config.landing.steps.step1.description}
              onChange={(e) => updateConfig(['landing', 'steps', 'step1', 'description'], e.target.value)}
              className="w-full border rounded px-3 py-2 h-20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">额外说明文字</label>
            <input
              type="text"
              value={config.landing.steps.step1.additionalNote || ''}
              onChange={(e) => updateConfig(['landing', 'steps', 'step1', 'additionalNote'], e.target.value)}
              className="w-full border rounded px-3 py-2"
              placeholder="在关键词下方显示的额外说明"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">关键词列表</label>
            {config.landing.steps.step1.keywords.map((keyword, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={keyword}
                  onChange={(e) => {
                    const newKeywords = [...config.landing.steps.step1.keywords];
                    newKeywords[index] = e.target.value;
                    updateConfig(['landing', 'steps', 'step1', 'keywords'], newKeywords);
                  }}
                  className="flex-1 border rounded px-3 py-2"
                />
                <button
                  onClick={() => removeArrayItem(['landing', 'steps', 'step1', 'keywords'], index)}
                  className="bg-red-500 text-white px-3 py-2 rounded"
                >
                  删除
                </button>
              </div>
            ))}
            <button
              onClick={() => addArrayItem(['landing', 'steps', 'step1', 'keywords'], '')}
              className="bg-blue-500 text-white px-4 py-2 rounded"
            >
              添加关键词
            </button>
          </div>
        </div>
      </div>

      {/* 第二步配置 */}
      <div className="border rounded p-4 bg-gray-50">
        <h3 className="text-lg font-medium mb-4">第二步配置</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">步骤标题</label>
            <input
              type="text"
              value={config.landing.steps.step2.title}
              onChange={(e) => updateConfig(['landing', 'steps', 'step2', 'title'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">步骤描述</label>
            <textarea
              value={config.landing.steps.step2.description}
              onChange={(e) => updateConfig(['landing', 'steps', 'step2', 'description'], e.target.value)}
              className="w-full border rounded px-3 py-2 h-20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">评论文案列表</label>
            {config.landing.steps.step2.comments.map((comment, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <textarea
                  value={comment}
                  onChange={(e) => {
                    const newComments = [...config.landing.steps.step2.comments];
                    newComments[index] = e.target.value;
                    updateConfig(['landing', 'steps', 'step2', 'comments'], newComments);
                  }}
                  className="flex-1 border rounded px-3 py-2 h-20"
                />
                <button
                  onClick={() => removeArrayItem(['landing', 'steps', 'step2', 'comments'], index)}
                  className="bg-red-500 text-white px-3 py-2 rounded"
                >
                  删除
                </button>
              </div>
            ))}
            <button
              onClick={() => addArrayItem(['landing', 'steps', 'step2', 'comments'], '')}
              className="bg-blue-500 text-white px-4 py-2 rounded"
            >
              添加评论文案
            </button>
          </div>
        </div>
      </div>

      {/* 第三步配置 */}
      <div className="border rounded p-4 bg-gray-50">
        <h3 className="text-lg font-medium mb-4">第三步配置</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">步骤标题</label>
            <input
              type="text"
              value={config.landing.steps.step3.title}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'title'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">步骤描述</label>
            <textarea
              value={config.landing.steps.step3.description}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'description'], e.target.value)}
              className="w-full border rounded px-3 py-2 h-24"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">示范图标题</label>
            <input
              type="text"
              value={config.landing.steps.step3.demoTitle || ''}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'demoTitle'], e.target.value)}
              className="w-full border rounded px-3 py-2"
              placeholder="示范图上方显示的文字，如：👇如下图所示👇"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">最后步骤标题</label>
            <input
              type="text"
              value={config.landing.steps.step3.finalStepTitle || ''}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'finalStepTitle'], e.target.value)}
              className="w-full border rounded px-3 py-2"
              placeholder="如：最后一步"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">提交截图说明</label>
            <input
              type="text"
              value={config.landing.steps.step3.finalNote}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'finalNote'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">审核时间说明</label>
            <input
              type="text"
              value={config.landing.steps.step3.finalDescription || ''}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'finalDescription'], e.target.value)}
              className="w-full border rounded px-3 py-2"
              placeholder="如：机器人会在(10)秒内审核完..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">警告文字</label>
            <input
              type="text"
              value={config.landing.steps.step3.warningText || ''}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'warningText'], e.target.value)}
              className="w-full border rounded px-3 py-2"
              placeholder="如：注意:不规范截图和上传重复截图将重置进度!"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">示例文字</label>
            <input
              type="text"
              value={config.landing.steps.step3.exampleText || ''}
              onChange={(e) => updateConfig(['landing', 'steps', 'step3', 'exampleText'], e.target.value)}
              className="w-full border rounded px-3 py-2"
              placeholder="如：已完成示例:👇👇👇"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">第三步示范图片</label>
            <p className="text-gray-600 text-sm mb-3">这些图片会显示在第三步说明下方，用于指导用户操作。支持本地上传图片文件</p>
            {config.landing.steps.step3.demoImages.map((image, index) => (
              <div key={index} className="border rounded p-4 mb-4 bg-white">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-medium">示范图 {index + 1}</span>
                  <button
                    onClick={() => removeArrayItem(['landing', 'steps', 'step3', 'demoImages'], index)}
                    className="bg-red-500 text-white px-3 py-1 rounded text-sm"
                  >
                    删除
                  </button>
                </div>
                
                {image && (
                  <div className="mb-3">
                    <img src={image} alt={`示范图 ${index + 1}`} className="w-32 h-20 object-cover rounded" />
                  </div>
                )}
                
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, ['landing', 'steps', 'step3', 'demoImages'], index)}
                      className="text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
                    <input
                      type="text"
                      value={image}
                      onChange={(e) => {
                        const newImages = [...config.landing.steps.step3.demoImages];
                        newImages[index] = e.target.value;
                        updateConfig(['landing', 'steps', 'step3', 'demoImages'], newImages);
                      }}
                      className="w-full border rounded px-2 py-1 text-sm"
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                </div>
              </div>
            ))}
            <button
              onClick={() => addArrayItem(['landing', 'steps', 'step3', 'demoImages'], '')}
              className="bg-blue-500 text-white px-4 py-2 rounded"
            >
              添加示范图片
            </button>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">轮播图片</label>
        <p className="text-gray-600 text-sm mb-3">支持本地上传图片文件</p>
        {config.landing.slides.map((slide, index) => (
          <div key={index} className="border rounded p-4 mb-4 bg-gray-50">
            <div className="flex justify-between items-center mb-3">
              <span className="font-medium">轮播图 {index + 1}</span>
              <button
                onClick={() => removeArrayItem(['landing', 'slides'], index)}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm"
              >
                删除
              </button>
            </div>
            
            {slide && (
              <div className="mb-3">
                <img src={slide} alt={`轮播图 ${index + 1}`} className="w-32 h-20 object-cover rounded" />
              </div>
            )}
            
            <div className="space-y-2">
              <div>
                <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload(e, ['landing', 'slides'], index)}
                  className="text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
                <input
                  type="text"
                  value={slide}
                  onChange={(e) => {
                    const newSlides = [...config.landing.slides];
                    newSlides[index] = e.target.value;
                    updateConfig(['landing', 'slides'], newSlides);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
          </div>
        ))}
        <button
          onClick={() => addArrayItem(['landing', 'slides'], '')}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          添加轮播图
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">奖励轮播图片</label>
        <p className="text-gray-600 text-sm mb-3">支持本地上传图片文件</p>
        {config.landing.rewardSlides.map((slide, index) => (
          <div key={index} className="border rounded p-4 mb-4 bg-gray-50">
            <div className="flex justify-between items-center mb-3">
              <span className="font-medium">奖励图 {index + 1}</span>
              <button
                onClick={() => removeArrayItem(['landing', 'rewardSlides'], index)}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm"
              >
                删除
              </button>
            </div>
            
            {slide && (
              <div className="mb-3">
                <img src={slide} alt={`奖励图 ${index + 1}`} className="w-32 h-20 object-cover rounded" />
              </div>
            )}
            
            <div className="space-y-2">
              <div>
                <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload(e, ['landing', 'rewardSlides'], index)}
                  className="text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
                <input
                  type="text"
                  value={slide}
                  onChange={(e) => {
                    const newSlides = [...config.landing.rewardSlides];
                    newSlides[index] = e.target.value;
                    updateConfig(['landing', 'rewardSlides'], newSlides);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
          </div>
        ))}
        <button
          onClick={() => addArrayItem(['landing', 'rewardSlides'], '')}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          添加奖励轮播图
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">机器人头像</label>
        <p className="text-gray-600 text-sm mb-3">支持本地上传图片文件</p>
        <div className="border rounded p-4 bg-gray-50">
          {config.landing.chatBotAvatar && (
            <div className="mb-3">
              <img src={config.landing.chatBotAvatar} alt="机器人头像" className="w-16 h-16 object-cover rounded-full" />
            </div>
          )}
          
          <div className="space-y-2">
            <div>
              <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      updateConfig(['landing', 'chatBotAvatar'], event.target?.result as string);
                    };
                    reader.readAsDataURL(file);
                  }
                }}
                className="text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
              <input
                type="text"
                value={config.landing.chatBotAvatar}
                onChange={(e) => updateConfig(['landing', 'chatBotAvatar'], e.target.value)}
                className="w-full border rounded px-2 py-1 text-sm"
                placeholder="https://example.com/avatar.jpg"
              />
            </div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">机器人欢迎消息</label>
        <textarea
          value={config.landing.chatBotWelcome}
          onChange={(e) => updateConfig(['landing', 'chatBotWelcome'], e.target.value)}
          className="w-full border rounded px-3 py-2 h-24"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">完成任务后的回复</label>
        <textarea
          value={config.landing.customReply}
          onChange={(e) => updateConfig(['landing', 'customReply'], e.target.value)}
          className="w-full border rounded px-3 py-2 h-32"
        />
      </div>
    </div>
  );

  const renderHomeConfig = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">页面标题</label>
        <input
          type="text"
          value={config.home.title}
          onChange={(e) => updateConfig(['home', 'title'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">分类标签</label>
        {config.home.categories.map((category, index) => (
          <div key={index} className="flex gap-2 mb-2">
            <input
              type="text"
              value={category}
              onChange={(e) => {
                const newCategories = [...config.home.categories];
                newCategories[index] = e.target.value;
                updateConfig(['home', 'categories'], newCategories);
              }}
              className="flex-1 border rounded px-3 py-2"
            />
            <button
              onClick={() => removeArrayItem(['home', 'categories'], index)}
              className="bg-red-500 text-white px-3 py-2 rounded"
            >
              删除
            </button>
          </div>
        ))}
        <button
          onClick={() => addArrayItem(['home', 'categories'], '')}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          添加分类
        </button>
      </div>

      {/* 新增预览图管理 */}
      <div>
        <label className="block text-sm font-medium mb-2">首页预览图管理</label>
        <p className="text-gray-600 text-sm mb-3">管理首页显示的预览图片和名称，支持本地上传图片文件</p>
        {(config.home.previewImages || []).map((previewImage, index) => (
          <div key={index} className="border rounded p-4 mb-4 bg-gray-50">
            <div className="flex justify-between items-center mb-3">
              <span className="font-medium">预览图 {index + 1}</span>
              <button
                onClick={() => removeArrayItem(['home', 'previewImages'], index)}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm"
              >
                删除
              </button>
            </div>
            
            {previewImage.url && (
              <div className="mb-3">
                <img src={previewImage.url} alt={previewImage.name} className="w-32 h-20 object-cover rounded" />
              </div>
            )}
            
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-gray-600 mb-1">预览图名称</label>
                <input
                  type="text"
                  value={previewImage.name}
                  onChange={(e) => {
                    const newPreviewImages = [...(config.home.previewImages || [])];
                    newPreviewImages[index] = { ...newPreviewImages[index], name: e.target.value };
                    updateConfig(['home', 'previewImages'], newPreviewImages);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="输入预览图名称"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const newPreviewImages = [...(config.home.previewImages || [])];
                        newPreviewImages[index] = { ...newPreviewImages[index], url: event.target?.result as string };
                        updateConfig(['home', 'previewImages'], newPreviewImages);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
                <input
                  type="text"
                  value={previewImage.url}
                  onChange={(e) => {
                    const newPreviewImages = [...(config.home.previewImages || [])];
                    newPreviewImages[index] = { ...newPreviewImages[index], url: e.target.value };
                    updateConfig(['home', 'previewImages'], newPreviewImages);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
          </div>
        ))}
        <button
          onClick={() => addArrayItem(['home', 'previewImages'], { name: '', url: '' })}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          添加预览图
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">页脚文字</label>
        <input
          type="text"
          value={config.home.footer}
          onChange={(e) => updateConfig(['home', 'footer'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">弹窗标题</label>
        <input
          type="text"
          value={config.home.modalTitle}
          onChange={(e) => updateConfig(['home', 'modalTitle'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">弹窗描述</label>
        <input
          type="text"
          value={config.home.modalDescription}
          onChange={(e) => updateConfig(['home', 'modalDescription'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">弹窗按钮文字</label>
        <input
          type="text"
          value={config.home.modalButtonText}
          onChange={(e) => updateConfig(['home', 'modalButtonText'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>
    </div>
  );

  const renderComicConfig = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">页面标题</label>
        <input
          type="text"
          value={config.comic.title}
          onChange={(e) => updateConfig(['comic', 'title'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      {/* 新增漫画列表管理 */}
      <div>
        <label className="block text-sm font-medium mb-2">漫画内容管理</label>
        <p className="text-gray-600 text-sm mb-3">管理漫画页面显示的漫画内容，支持本地上传图片文件</p>
        {(config.comic.comics || []).map((comic, index) => (
          <div key={index} className="border rounded p-4 mb-4 bg-gray-50">
            <div className="flex justify-between items-center mb-3">
              <span className="font-medium">漫画 {index + 1}</span>
              <button
                onClick={() => removeArrayItem(['comic', 'comics'], index)}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm"
              >
                删除
              </button>
            </div>
            
            {comic.thumbnail && (
              <div className="mb-3">
                <img src={comic.thumbnail} alt={comic.title} className="w-32 h-20 object-cover rounded" />
              </div>
            )}
            
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-gray-600 mb-1">漫画标题</label>
                <input
                  type="text"
                  value={comic.title}
                  onChange={(e) => {
                    const newComics = [...(config.comic.comics || [])];
                    newComics[index] = { ...newComics[index], title: e.target.value };
                    updateConfig(['comic', 'comics'], newComics);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="输入漫画标题"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">章节数</label>
                <input
                  type="text"
                  value={comic.chapters}
                  onChange={(e) => {
                    const newComics = [...(config.comic.comics || [])];
                    newComics[index] = { ...newComics[index], chapters: e.target.value };
                    updateConfig(['comic', 'comics'], newComics);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="如：72话"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">评分</label>
                <input
                  type="text"
                  value={comic.rating}
                  onChange={(e) => {
                    const newComics = [...(config.comic.comics || [])];
                    newComics[index] = { ...newComics[index], rating: e.target.value };
                    updateConfig(['comic', 'comics'], newComics);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="如：9.8"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const newComics = [...(config.comic.comics || [])];
                        newComics[index] = { ...newComics[index], thumbnail: event.target?.result as string };
                        updateConfig(['comic', 'comics'], newComics);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
                <input
                  type="text"
                  value={comic.thumbnail}
                  onChange={(e) => {
                    const newComics = [...(config.comic.comics || [])];
                    newComics[index] = { ...newComics[index], thumbnail: e.target.value };
                    updateConfig(['comic', 'comics'], newComics);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
          </div>
        ))}
        <button
          onClick={() => addArrayItem(['comic', 'comics'], { title: '', chapters: '', rating: '', thumbnail: '' })}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          添加漫画
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">页脚文字</label>
        <input
          type="text"
          value={config.comic.footer}
          onChange={(e) => updateConfig(['comic', 'footer'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      {/* 新增弹窗配置 */}
      <div>
        <label className="block text-sm font-medium mb-2">弹窗标题</label>
        <input
          type="text"
          value={config.comic.modalTitle || '白嫖到底'}
          onChange={(e) => updateConfig(['comic', 'modalTitle'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">弹窗描述</label>
        <input
          type="text"
          value={config.comic.modalDescription || '立即登录,畅享海量独家漫画'}
          onChange={(e) => updateConfig(['comic', 'modalDescription'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">弹窗按钮文字</label>
        <input
          type="text"
          value={config.comic.modalButtonText || '稍后决定'}
          onChange={(e) => updateConfig(['comic', 'modalButtonText'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>
    </div>
  );

  const renderGameConfig = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">页面标题</label>
        <input
          type="text"
          value={config.game.title}
          onChange={(e) => updateConfig(['game', 'title'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      {/* 新增游戏列表管理 */}
      <div>
        <label className="block text-sm font-medium mb-2">游戏内容管理</label>
        <p className="text-gray-600 text-sm mb-3">管理游戏页面显示的游戏内容，支持本地上传图片文件</p>
        {(config.game.games || []).map((game, index) => (
          <div key={index} className="border rounded p-4 mb-4 bg-gray-50">
            <div className="flex justify-between items-center mb-3">
              <span className="font-medium">游戏 {index + 1}</span>
              <button
                onClick={() => removeArrayItem(['game', 'games'], index)}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm"
              >
                删除
              </button>
            </div>
            
            {game.thumbnail && (
              <div className="mb-3">
                <img src={game.thumbnail} alt={game.title} className="w-32 h-20 object-cover rounded" />
              </div>
            )}
            
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-gray-600 mb-1">游戏标题</label>
                <input
                  type="text"
                  value={game.title}
                  onChange={(e) => {
                    const newGames = [...(config.game.games || [])];
                    newGames[index] = { ...newGames[index], title: e.target.value };
                    updateConfig(['game', 'games'], newGames);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="输入游戏标题"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">游戏类型</label>
                <input
                  type="text"
                  value={game.tag}
                  onChange={(e) => {
                    const newGames = [...(config.game.games || [])];
                    newGames[index] = { ...newGames[index], tag: e.target.value };
                    updateConfig(['game', 'games'], newGames);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="如：角色扮演"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">游戏模式</label>
                <input
                  type="text"
                  value={game.mode}
                  onChange={(e) => {
                    const newGames = [...(config.game.games || [])];
                    newGames[index] = { ...newGames[index], mode: e.target.value };
                    updateConfig(['game', 'games'], newGames);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="如：多人"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">评分</label>
                <input
                  type="text"
                  value={game.rating}
                  onChange={(e) => {
                    const newGames = [...(config.game.games || [])];
                    newGames[index] = { ...newGames[index], rating: e.target.value };
                    updateConfig(['game', 'games'], newGames);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="如：8.7"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const newGames = [...(config.game.games || [])];
                        newGames[index] = { ...newGames[index], thumbnail: event.target?.result as string };
                        updateConfig(['game', 'games'], newGames);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
                <input
                  type="text"
                  value={game.thumbnail}
                  onChange={(e) => {
                    const newGames = [...(config.game.games || [])];
                    newGames[index] = { ...newGames[index], thumbnail: e.target.value };
                    updateConfig(['game', 'games'], newGames);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
          </div>
        ))}
        <button
          onClick={() => addArrayItem(['game', 'games'], { title: '', tag: '', mode: '', rating: '', thumbnail: '' })}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          添加游戏
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">页脚文字</label>
        <input
          type="text"
          value={config.game.footer}
          onChange={(e) => updateConfig(['game', 'footer'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      {/* 新增弹窗配置 */}
      <div>
        <label className="block text-sm font-medium mb-2">弹窗标题</label>
        <input
          type="text"
          value={config.game.modalTitle || '嘎嘎白嫖'}
          onChange={(e) => updateConfig(['game', 'modalTitle'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">弹窗描述</label>
        <input
          type="text"
          value={config.game.modalDescription || '立即登录,享受海量独家游戏'}
          onChange={(e) => updateConfig(['game', 'modalDescription'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">弹窗按钮文字</label>
        <input
          type="text"
          value={config.game.modalButtonText || '稍后决定'}
          onChange={(e) => updateConfig(['game', 'modalButtonText'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>
    </div>
  );

  const renderPaymentConfig = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">页面标题</label>
        <input
          type="text"
          value={config.payment.title}
          onChange={(e) => updateConfig(['payment', 'title'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">页面副标题</label>
        <textarea
          value={config.payment.subtitle}
          onChange={(e) => updateConfig(['payment', 'subtitle'], e.target.value)}
          className="w-full border rounded px-3 py-2 h-20"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">头像图片</label>
        <p className="text-gray-600 text-sm mb-3">支持本地上传图片文件</p>
        <div className="border rounded p-4 bg-gray-50">
          {config.payment.avatar && (
            <div className="mb-3">
              <img src={config.payment.avatar} alt="头像" className="w-16 h-16 object-cover rounded-full" />
            </div>
          )}
          
          <div className="space-y-2">
            <div>
              <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      updateConfig(['payment', 'avatar'], event.target?.result as string);
                    };
                    reader.readAsDataURL(file);
                  }
                }}
                className="text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
              <input
                type="text"
                value={config.payment.avatar}
                onChange={(e) => updateConfig(['payment', 'avatar'], e.target.value)}
                className="w-full border rounded px-2 py-1 text-sm"
                placeholder="https://example.com/avatar.jpg"
              />
            </div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">二维码图片</label>
        <p className="text-gray-600 text-sm mb-3">支持本地上传图片文件</p>
        <div className="border rounded p-4 bg-gray-50">
          {config.payment.qrCode && (
            <div className="mb-3">
              <img src={config.payment.qrCode} alt="二维码" className="w-32 h-32 object-cover rounded" />
            </div>
          )}
          
          <div className="space-y-2">
            <div>
              <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      updateConfig(['payment', 'qrCode'], event.target?.result as string);
                    };
                    reader.readAsDataURL(file);
                  }
                }}
                className="text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
              <input
                type="text"
                value={config.payment.qrCode}
                onChange={(e) => updateConfig(['payment', 'qrCode'], e.target.value)}
                className="w-full border rounded px-2 py-1 text-sm"
                placeholder="https://example.com/qrcode.jpg"
              />
            </div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">说明文字</label>
        <div className="space-y-3">
          <div>
            <label className="block text-xs text-gray-600 mb-1">第一行说明</label>
            <input
              type="text"
              value={config.payment.linkText1}
              onChange={(e) => updateConfig(['payment', 'linkText1'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">第二行说明前半部分</label>
            <input
              type="text"
              value={config.payment.linkText2}
              onChange={(e) => updateConfig(['payment', 'linkText2'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">第二行说明后半部分</label>
            <input
              type="text"
              value={config.payment.linkText3}
              onChange={(e) => updateConfig(['payment', 'linkText3'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">第三行说明</label>
            <input
              type="text"
              value={config.payment.linkText4}
              onChange={(e) => updateConfig(['payment', 'linkText4'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">内容副标题</label>
        <input
          type="text"
          value={config.payment.contentSubtitle}
          onChange={(e) => updateConfig(['payment', 'contentSubtitle'], e.target.value)}
          className="w-full border rounded px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">预览图片</label>
        <p className="text-gray-600 text-sm mb-3">支持本地上传图片文件</p>
        {config.payment.previewImages.map((image, index) => (
          <div key={index} className="border rounded p-4 mb-4 bg-gray-50">
            <div className="flex justify-between items-center mb-3">
              <span className="font-medium">预览图 {index + 1}</span>
              <button
                onClick={() => removeArrayItem(['payment', 'previewImages'], index)}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm"
              >
                删除
              </button>
            </div>
            
            {image && (
              <div className="mb-3">
                <img src={image} alt={`预览图 ${index + 1}`} className="w-32 h-20 object-cover rounded" />
              </div>
            )}
            
            <div className="space-y-2">
              <div>
                <label className="block text-xs text-gray-600 mb-1">上传本地图片</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload(e, ['payment', 'previewImages'], index)}
                  className="text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">或输入图片链接</label>
                <input
                  type="text"
                  value={image}
                  onChange={(e) => {
                    const newImages = [...config.payment.previewImages];
                    newImages[index] = e.target.value;
                    updateConfig(['payment', 'previewImages'], newImages);
                  }}
                  className="w-full border rounded px-2 py-1 text-sm"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
          </div>
        ))}
        <button
          onClick={() => addArrayItem(['payment', 'previewImages'], '')}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          添加预览图片
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">聊天机器人配置</label>
        <div className="space-y-4 border rounded p-4 bg-gray-50">
          <div>
            <label className="block text-xs text-gray-600 mb-1">机器人名称</label>
            <input
              type="text"
              value={config.payment.chatBot.name}
              onChange={(e) => updateConfig(['payment', 'chatBot', 'name'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-600 mb-1">客服名称</label>
            <input
              type="text"
              value={config.payment.chatBot.customerName}
              onChange={(e) => updateConfig(['payment', 'chatBot', 'customerName'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-xs text-gray-600 mb-1">在线状态</label>
            <input
              type="text"
              value={config.payment.chatBot.status}
              onChange={(e) => updateConfig(['payment', 'chatBot', 'status'], e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-xs text-gray-600 mb-1">机器人头像</label>
            {config.payment.chatBot.avatar && (
              <div className="mb-2">
                <img src={config.payment.chatBot.avatar} alt="机器人头像" className="w-12 h-12 object-cover rounded-full" />
              </div>
            )}
            <div className="space-y-2">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      updateConfig(['payment', 'chatBot', 'avatar'], event.target?.result as string);
                    };
                    reader.readAsDataURL(file);
                  }
                }}
                className="text-sm"
              />
              <input
                type="text"
                value={config.payment.chatBot.avatar}
                onChange={(e) => updateConfig(['payment', 'chatBot', 'avatar'], e.target.value)}
                className="w-full border rounded px-2 py-1 text-sm"
                placeholder="https://example.com/avatar.jpg"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-gray-600 mb-1">欢迎消息</label>
            <textarea
              value={config.payment.chatBot.welcomeMessage}
              onChange={(e) => updateConfig(['payment', 'chatBot', 'welcomeMessage'], e.target.value)}
              className="w-full border rounded px-3 py-2 h-24"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-600 mb-1">支付成功自动回复</label>
            <textarea
              value={config.payment.chatBot.paymentSuccessReply || '🎉 恭喜！检测到您的支付成功！\n\n正在为您处理资源发送...\n\n📚 同人动漫合集：https://pan.baidu.com/xxx\n📖 漫画资源包：https://pan.baidu.com/xxx\n🎮 3D同人游戏：https://pan.baidu.com/xxx\n💎 JM软件：https://pan.baidu.com/xxx\n\n感谢您的支持！请保存好这些链接。'}
              onChange={(e) => updateConfig(['payment', 'chatBot', 'paymentSuccessReply'], e.target.value)}
              className="w-full border rounded px-3 py-2 h-24"
              placeholder="当用户发送包含'支付成功'等关键词时的自动回复"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-600 mb-1">价格确认自动回复</label>
            <textarea
              value={config.payment.chatBot.priceConfirmReply || '💰 确认价格：19.90元\n\n包含内容：\n📚 500G同人动漫资源\n🎮 3D同人游戏合集\n📖 高清漫画资源包\n\n请扫描上方二维码完成支付，支付后发送截图即可获取所有资源！'}
              onChange={(e) => updateConfig(['payment', 'chatBot', 'priceConfirmReply'], e.target.value)}
              className="w-full border rounded px-3 py-2 h-24"
              placeholder="当用户发送包含'19.9'等价格关键词时的自动回复"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-600 mb-1">默认自动回复</label>
            <textarea
              value={config.payment.chatBot.defaultReply || '请将付款的截图发送给我\n后台审核通过后我会发送所有资源的链接~\n注意:付款金额不对是无法通过审核的哦!'}
              onChange={(e) => updateConfig(['payment', 'chatBot', 'defaultReply'], e.target.value)}
              className="w-full border rounded px-3 py-2 h-24"
              placeholder="其他情况下的默认自动回复"
            />
          </div>

        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-6xl mx-auto p-4">
        <div className="bg-white rounded-lg shadow-md">
          <div className="border-b p-4">
            <h1 className="text-2xl font-bold text-gray-800">网站内容管理后台</h1>
            <p className="text-gray-600 mt-2">管理所有页面的文字和图片内容</p>
          </div>

          {/* 标签导航 */}
          <div className="flex border-b">
            {[
              { key: 'landing', label: '首页教程' },
              { key: 'home', label: '视频页面' },
              { key: 'comic', label: '漫画页面' },
              { key: 'game', label: '游戏页面' },
              { key: 'payment', label: '付费页面' }
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`px-6 py-3 font-medium ${
                  activeTab === tab.key
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* 内容区域 */}
          <div className="p-6">
            {activeTab === 'landing' && renderLandingConfig()}
            {activeTab === 'home' && renderHomeConfig()}
            {activeTab === 'comic' && renderComicConfig()}
            {activeTab === 'game' && renderGameConfig()}
            {activeTab === 'payment' && renderPaymentConfig()}

            {/* 保存按钮 */}
            <div className="mt-8 pt-6 border-t">
              <div className="flex items-center justify-between">
                <button
                  onClick={saveConfig}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded font-medium"
                >
                  保存所有配置
                </button>
                {savedMessage && (
                  <span className="text-green-600 font-medium">{savedMessage}</span>
                )}
              </div>
              <p className="text-gray-500 text-sm mt-2">
                保存后，所有页面将使用新的配置内容
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
