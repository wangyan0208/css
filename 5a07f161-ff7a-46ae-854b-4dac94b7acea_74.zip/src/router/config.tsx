
import { RouteObject } from 'react-router-dom';
import { lazy } from 'react';

const HomePage = lazy(() => import('../pages/home/page'));
const LandingPage = lazy(() => import('../pages/landing/page'));
const ComicPage = lazy(() => import('../pages/comic/page'));
const GamePage = lazy(() => import('../pages/game/page'));
const PaymentPage = lazy(() => import('../pages/payment/page'));
const AdminPage = lazy(() => import('../pages/admin/page'));
const NotFound = lazy(() => import('../pages/NotFound'));

const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />
  },
  {
    path: '/home',
    element: <HomePage />
  },
  {
    path: '/landing',
    element: <LandingPage />
  },
  {
    path: '/comic',
    element: <ComicPage />
  },
  {
    path: '/game',
    element: <GamePage />
  },
  {
    path: '/payment', 
    element: <PaymentPage />
  },
  {
    path: '/admin',
    element: <AdminPage />
  },
  {
    path: '*',
    element: <NotFound />
  }
];

export default routes;
